// components/social/FacebookLoginButton.tsx
'use client';

import { signIn } from 'next-auth/react';
import { useState } from 'react';

interface FacebookLoginButtonProps {
  onSuccess?: () => void;
  onError?: (error: Error) => void;
  className?: string;
}

export function FacebookLoginButton({ 
  onSuccess, 
  onError,
  className = '' 
}: FacebookLoginButtonProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    setIsLoading(true);
    try {
      const result = await signIn('facebook', { 
        callbackUrl: '/feed',
        redirect: false,
      });
      
      if (result?.error) {
        throw new Error(result.error);
      }
      
      onSuccess?.();
    } catch (error) {
      onError?.(error as Error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      onClick={handleLogin}
      disabled={isLoading}
      className={`
        flex items-center justify-center gap-3 
        w-full px-4 py-3 
        bg-[#1877F2] hover:bg-[#166FE5] 
        text-white font-medium rounded-lg
        transition-colors
        disabled:opacity-50
        ${className}
      `}
    >
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
      </svg>
      {isLoading ? 'Connecting...' : 'Continue with Facebook'}
    </button>
  );
}


// components/social/ShareButtons.tsx
'use client';

import { useState } from 'react';

interface ShareButtonsProps {
  url: string;
  title: string;
  description?: string;
}

export function ShareButtons({ url, title, description }: ShareButtonsProps) {
  const [copied, setCopied] = useState(false);

  const shareToFacebook = () => {
    const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(title)}`;
    window.open(fbUrl, 'facebook-share', 'width=580,height=400');
  };

  const shareToTwitter = () => {
    const twitterUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`;
    window.open(twitterUrl, 'twitter-share', 'width=580,height=400');
  };

  const shareToLinkedIn = () => {
    const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
    window.open(linkedInUrl, 'linkedin-share', 'width=580,height=400');
  };

  const copyLink = async () => {
    await navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex items-center gap-2">
      {/* Facebook */}
      <button
        onClick={shareToFacebook}
        className="p-2 rounded-full bg-[#1877F2] hover:bg-[#166FE5] text-white transition-colors"
        title="Share on Facebook"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      </button>

      {/* Twitter/X */}
      <button
        onClick={shareToTwitter}
        className="p-2 rounded-full bg-black hover:bg-gray-800 text-white transition-colors"
        title="Share on X"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
        </svg>
      </button>

      {/* LinkedIn */}
      <button
        onClick={shareToLinkedIn}
        className="p-2 rounded-full bg-[#0A66C2] hover:bg-[#004182] text-white transition-colors"
        title="Share on LinkedIn"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
        </svg>
      </button>

      {/* Copy Link */}
      <button
        onClick={copyLink}
        className={`p-2 rounded-full transition-colors ${
          copied 
            ? 'bg-green-500 text-white' 
            : 'bg-gray-200 hover:bg-gray-300 text-gray-700 dark:bg-gray-700 dark:hover:bg-gray-600 dark:text-gray-300'
        }`}
        title={copied ? 'Copied!' : 'Copy link'}
      >
        {copied ? (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        ) : (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
          </svg>
        )}
      </button>
    </div>
  );
}


// components/social/FacebookPageWidget.tsx
'use client';

import { useEffect, useRef } from 'react';

interface FacebookPageWidgetProps {
  pageUrl: string;
  width?: number;
  height?: number;
  showTimeline?: boolean;
  showEvents?: boolean;
  showMessages?: boolean;
}

export function FacebookPageWidget({
  pageUrl,
  width = 340,
  height = 500,
  showTimeline = true,
  showEvents = false,
  showMessages = false,
}: FacebookPageWidgetProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Re-parse Facebook plugins when component mounts
    if (typeof window !== 'undefined' && (window as any).FB) {
      (window as any).FB.XFBML.parse(containerRef.current);
    }
  }, []);

  const tabs = [
    showTimeline && 'timeline',
    showEvents && 'events',
    showMessages && 'messages',
  ].filter(Boolean).join(',');

  return (
    <div ref={containerRef}>
      <div
        className="fb-page"
        data-href={pageUrl}
        data-tabs={tabs}
        data-width={width}
        data-height={height}
        data-small-header="false"
        data-adapt-container-width="true"
        data-hide-cover="false"
        data-show-facepile="true"
      />
    </div>
  );
}


// components/social/InviteFriends.tsx
'use client';

import { useState } from 'react';

interface InviteFriendsProps {
  referralCode: string;
  referralUrl: string;
}

export function InviteFriends({ referralCode, referralUrl }: InviteFriendsProps) {
  const [copied, setCopied] = useState(false);

  const shareMessage = `Join me on MedInvest - the premier community for healthcare professionals and investors! Use my referral code: ${referralCode}`;

  const shareToFacebook = () => {
    const url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralUrl)}&quote=${encodeURIComponent(shareMessage)}`;
    window.open(url, 'facebook-share', 'width=580,height=400');
  };

  const shareViaMessenger = () => {
    const url = `fb-messenger://share?link=${encodeURIComponent(referralUrl)}`;
    window.location.href = url;
  };

  const shareViaWhatsApp = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(shareMessage + ' ' + referralUrl)}`;
    window.open(url, '_blank');
  };

  const copyLink = async () => {
    await navigator.clipboard.writeText(referralUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
        Invite Friends & Earn Rewards
      </h3>
      <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
        Share MedInvest with colleagues. Get 1 month free Premium for each friend who joins!
      </p>

      {/* Referral Code */}
      <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 mb-4">
        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Your referral code</p>
        <div className="flex items-center justify-between">
          <span className="font-mono font-bold text-lg text-gray-900 dark:text-white">
            {referralCode}
          </span>
          <button
            onClick={copyLink}
            className="text-blue-600 hover:text-blue-700 text-sm font-medium"
          >
            {copied ? 'Copied!' : 'Copy Link'}
          </button>
        </div>
      </div>

      {/* Share Buttons */}
      <div className="grid grid-cols-3 gap-3">
        <button
          onClick={shareToFacebook}
          className="flex flex-col items-center gap-1 p-3 rounded-lg bg-[#1877F2] hover:bg-[#166FE5] text-white transition-colors"
        >
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
          </svg>
          <span className="text-xs">Facebook</span>
        </button>

        <button
          onClick={shareViaMessenger}
          className="flex flex-col items-center gap-1 p-3 rounded-lg bg-gradient-to-r from-[#00B2FF] to-[#006AFF] hover:opacity-90 text-white transition-opacity"
        >
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 0C5.373 0 0 4.974 0 11.111c0 3.498 1.744 6.614 4.469 8.654V24l4.088-2.242c1.092.301 2.246.464 3.443.464 6.627 0 12-4.974 12-11.111S18.627 0 12 0zm1.191 14.963l-3.055-3.26-5.963 3.26L10.732 8l3.131 3.259L19.752 8l-6.561 6.963z"/>
          </svg>
          <span className="text-xs">Messenger</span>
        </button>

        <button
          onClick={shareViaWhatsApp}
          className="flex flex-col items-center gap-1 p-3 rounded-lg bg-[#25D366] hover:bg-[#20BD5A] text-white transition-colors"
        >
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
          <span className="text-xs">WhatsApp</span>
        </button>
      </div>

      {/* Stats */}
      <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600 dark:text-gray-400">Friends invited</span>
          <span className="font-medium text-gray-900 dark:text-white">12</span>
        </div>
        <div className="flex justify-between text-sm mt-1">
          <span className="text-gray-600 dark:text-gray-400">Free months earned</span>
          <span className="font-medium text-green-600">3</span>
        </div>
      </div>
    </div>
  );
}
