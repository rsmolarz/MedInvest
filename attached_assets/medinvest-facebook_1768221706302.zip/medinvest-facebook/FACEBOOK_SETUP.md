# Facebook Integration Setup Guide

## Overview

This guide covers connecting MedInvest to Facebook to drive user acquisition:

| Feature | Purpose | Effort |
|---------|---------|--------|
| Facebook Login | Easy signup/login | Low |
| Share Buttons | Users share content | Low |
| Facebook Pixel | Track conversions, retargeting | Low |
| Messenger Chat | Customer support | Low |
| Auto-post to Page | Content syndication | Medium |
| Facebook Ads | Paid acquisition | Medium |

---

## Step 1: Create Facebook App

1. Go to [developers.facebook.com](https://developers.facebook.com)
2. Click **My Apps** → **Create App**
3. Choose **Consumer** (or Business if you need Pages API)
4. Enter app name: "MedInvest"
5. Get your **App ID** and **App Secret**

---

## Step 2: Configure Facebook Login

### In Facebook Developer Console:

1. Go to **Add Product** → **Facebook Login** → **Set Up**
2. Choose **Web**
3. Enter site URL: `https://medinvest.com`
4. Go to **Settings** → **Basic**:
   - App Domains: `medinvest.com`
   - Privacy Policy URL: `https://medinvest.com/privacy`
   - Terms of Service URL: `https://medinvest.com/terms`
5. Go to **Facebook Login** → **Settings**:
   - Valid OAuth Redirect URIs: `https://medinvest.com/api/auth/callback/facebook`

### In your Web App:

```bash
npm install next-auth @auth/core
```

Add to `.env.local`:
```env
FACEBOOK_CLIENT_ID=your_app_id
FACEBOOK_CLIENT_SECRET=your_app_secret
NEXTAUTH_URL=https://medinvest.com
NEXTAUTH_SECRET=your_random_secret
```

Add to `app/api/auth/[...nextauth]/route.ts`:
```ts
import NextAuth from 'next-auth';
import FacebookProvider from 'next-auth/providers/facebook';

const handler = NextAuth({
  providers: [
    FacebookProvider({
      clientId: process.env.FACEBOOK_CLIENT_ID!,
      clientSecret: process.env.FACEBOOK_CLIENT_SECRET!,
    }),
  ],
});

export { handler as GET, handler as POST };
```

Add login button:
```tsx
import { signIn } from 'next-auth/react';

<button onClick={() => signIn('facebook')}>
  Continue with Facebook
</button>
```

---

## Step 3: Set Up Facebook Pixel

### In Facebook Business Manager:

1. Go to [business.facebook.com](https://business.facebook.com)
2. **Events Manager** → **Connect Data Sources** → **Web**
3. Name your pixel: "MedInvest Pixel"
4. Copy your **Pixel ID**

### In your Web App:

Add to `.env.local`:
```env
NEXT_PUBLIC_FACEBOOK_PIXEL_ID=your_pixel_id
```

Add `<FacebookPixel />` to your root layout:
```tsx
// app/layout.tsx
import { FacebookPixel } from '@/components/FacebookPixel';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        {children}
        <FacebookPixel />
      </body>
    </html>
  );
}
```

Track events:
```tsx
import { fbTrack } from '@/lib/facebook/FacebookIntegration';

// On signup
fbTrack.completeRegistration('email');

// On viewing a deal
fbTrack.viewContent({ id: 123, title: 'AI Diagnostics', sector: 'Digital Health' });

// On expressing interest
fbTrack.initiateCheckout({ id: 123, title: 'AI Diagnostics', value: 25000 });
```

---

## Step 4: Create Facebook Page

1. Go to [facebook.com/pages/create](https://www.facebook.com/pages/create)
2. Choose **Business or Brand**
3. Name: "MedInvest - Healthcare Investment Community"
4. Category: "Finance" or "Health & Wellness"
5. Add profile picture (logo) and cover image
6. Fill out About section with links to your app

### Page Content Strategy:

| Content Type | Frequency | Purpose |
|-------------|-----------|---------|
| New deals | As posted | Drive deal views |
| Trending posts | Weekly | Showcase community |
| Industry news | 2-3x/week | Establish authority |
| Tips & insights | Weekly | Value content |
| User testimonials | Monthly | Social proof |

---

## Step 5: Auto-Post to Facebook Page

### Get Page Access Token:

1. In Facebook Developer Console, go to **Tools** → **Graph API Explorer**
2. Select your app
3. Click **Get Token** → **Get Page Access Token**
4. Select your page
5. Request permissions: `pages_manage_posts`, `pages_read_engagement`
6. Copy the token

**Important**: Convert to long-lived token:
```bash
curl "https://graph.facebook.com/v18.0/oauth/access_token?grant_type=fb_exchange_token&client_id=YOUR_APP_ID&client_secret=YOUR_APP_SECRET&fb_exchange_token=YOUR_SHORT_LIVED_TOKEN"
```

### In your Backend:

Add to `.env`:
```env
FACEBOOK_PAGE_ID=your_page_id
FACEBOOK_PAGE_ACCESS_TOKEN=your_long_lived_token
```

Auto-post when deals are created:
```ts
// In your deal creation handler
import { shareNewDealToPage } from '@/services/FacebookPageService';

async function createDeal(dealData) {
  const deal = await prisma.deal.create({ data: dealData });
  
  // Auto-post to Facebook Page
  if (process.env.NODE_ENV === 'production') {
    await shareNewDealToPage(deal);
  }
  
  return deal;
}
```

---

## Step 6: Add Messenger Chat

### In Facebook Page Settings:

1. Go to your Facebook Page
2. **Settings** → **Messaging**
3. Enable **Add Messenger to your website**
4. Customize greeting message

### In your Web App:

Add to `.env.local`:
```env
NEXT_PUBLIC_FACEBOOK_PAGE_ID=your_page_id
```

Add `<MessengerChat />` to layout:
```tsx
import { MessengerChat } from '@/components/MessengerChat';

// In layout.tsx
<MessengerChat />
```

---

## Step 7: Add Share Buttons

```tsx
import { sharePost, shareDeal } from '@/lib/facebook/FacebookIntegration';

// On a post
<button onClick={() => sharePost({ id: post.id, content: post.content })}>
  Share on Facebook
</button>

// On a deal
<button onClick={() => shareDeal({ id: deal.id, title: deal.title, companyName: deal.company_name })}>
  Share on Facebook
</button>
```

---

## Step 8: Facebook Ads (Optional)

### Create Custom Audiences from Pixel:

1. Go to **Ads Manager** → **Audiences**
2. **Create Audience** → **Custom Audience** → **Website**
3. Create audiences:
   - All visitors (last 30 days)
   - Viewed deals but didn't sign up
   - Signed up but didn't express interest
   - High-intent users (viewed 3+ deals)

### Lookalike Audiences:

1. **Create Audience** → **Lookalike Audience**
2. Source: Your signup custom audience
3. Location: Your target countries
4. Size: 1-3% (most similar)

### Campaign Ideas:

| Objective | Audience | Creative |
|-----------|----------|----------|
| Awareness | Lookalike of signups | "Join 10,000+ healthcare investors" |
| Traffic | Interest: Healthcare, Investing | Feature top deals |
| Conversions | Retarget visitors | "Complete your profile" |
| Lead Gen | Lookalike + healthcare interests | "Get exclusive deal access" |

---

## Environment Variables Summary

```env
# Web App (.env.local)
FACEBOOK_CLIENT_ID=123456789
FACEBOOK_CLIENT_SECRET=abc123...
NEXT_PUBLIC_FACEBOOK_PIXEL_ID=123456789
NEXT_PUBLIC_FACEBOOK_PAGE_ID=123456789
NEXT_PUBLIC_FACEBOOK_APP_ID=123456789

# Backend (.env)
FACEBOOK_PAGE_ID=123456789
FACEBOOK_PAGE_ACCESS_TOKEN=EAAxxxxx...
```

---

## Mobile App Integration

For React Native/Expo, use:

```bash
npx expo install expo-auth-session expo-web-browser
```

```tsx
import * as Facebook from 'expo-auth-session/providers/facebook';
import * as WebBrowser from 'expo-web-browser';

WebBrowser.maybeCompleteAuthSession();

function FacebookLogin() {
  const [request, response, promptAsync] = Facebook.useAuthRequest({
    clientId: 'YOUR_APP_ID',
  });

  useEffect(() => {
    if (response?.type === 'success') {
      const { access_token } = response.params;
      // Send to your backend
    }
  }, [response]);

  return (
    <Button title="Login with Facebook" onPress={() => promptAsync()} />
  );
}
```

---

## Compliance Notes

1. **Privacy Policy**: Must mention Facebook data usage
2. **Data Deletion**: Implement callback for Facebook data deletion requests
3. **App Review**: For auto-posting, need `pages_manage_posts` permission (requires review)
4. **GDPR**: Get consent before tracking with Pixel in EU

---

## Testing

1. **Pixel**: Use [Facebook Pixel Helper](https://chrome.google.com/webstore/detail/facebook-pixel-helper) Chrome extension
2. **Login**: Test with Facebook test users in App Dashboard
3. **Share**: Test share dialogs open correctly
4. **Page Posts**: Test in development mode first (only admins see posts)
