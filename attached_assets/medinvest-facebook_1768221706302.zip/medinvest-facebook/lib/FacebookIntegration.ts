// lib/facebook/FacebookIntegration.ts
/**
 * Facebook Integration for MedInvest
 * 
 * Features:
 * 1. Facebook Login (OAuth) - Sign up/login with Facebook
 * 2. Share to Facebook - Share posts/deals to Facebook
 * 3. Facebook Page Integration - Auto-post content to your FB Page
 * 4. Facebook Pixel - Track conversions and retarget users
 * 5. Facebook Comments Plugin - Embed FB comments
 * 6. Messenger Chat Plugin - Customer support via Messenger
 */

// =============================================================================
// 1. FACEBOOK LOGIN (OAuth)
// =============================================================================

// Web: next-auth configuration
// pages/api/auth/[...nextauth].ts

import NextAuth from 'next-auth';
import FacebookProvider from 'next-auth/providers/facebook';

export const authOptions = {
  providers: [
    FacebookProvider({
      clientId: process.env.FACEBOOK_CLIENT_ID!,
      clientSecret: process.env.FACEBOOK_CLIENT_SECRET!,
      authorization: {
        params: {
          scope: 'email,public_profile',
        },
      },
    }),
    // ... other providers
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      // Create or update user in your database
      const response = await fetch(`${process.env.API_URL}/auth/facebook`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          facebookId: account?.providerAccountId,
          email: user.email,
          name: user.name,
          image: user.image,
          accessToken: account?.access_token,
        }),
      });
      
      return response.ok;
    },
    async jwt({ token, account }) {
      if (account) {
        token.accessToken = account.access_token;
        token.facebookId = account.providerAccountId;
      }
      return token;
    },
    async session({ session, token }) {
      session.accessToken = token.accessToken;
      return session;
    },
  },
};

export default NextAuth(authOptions);


// =============================================================================
// 2. FACEBOOK SHARE FUNCTIONALITY
// =============================================================================

interface ShareOptions {
  url: string;
  quote?: string;
  hashtag?: string;
}

export function shareToFacebook({ url, quote, hashtag }: ShareOptions) {
  const params = new URLSearchParams({
    u: url,
    ...(quote && { quote }),
    ...(hashtag && { hashtag: `#${hashtag}` }),
  });
  
  const shareUrl = `https://www.facebook.com/sharer/sharer.php?${params}`;
  
  window.open(shareUrl, 'facebook-share', 'width=580,height=400');
}

// Share a post
export function sharePost(post: { id: number; content: string }) {
  shareToFacebook({
    url: `https://medinvest.com/posts/${post.id}`,
    quote: post.content.substring(0, 200),
    hashtag: 'MedInvest',
  });
}

// Share a deal
export function shareDeal(deal: { id: number; title: string; companyName: string }) {
  shareToFacebook({
    url: `https://medinvest.com/deals/${deal.id}`,
    quote: `Check out ${deal.companyName}: ${deal.title} on MedInvest`,
    hashtag: 'HealthcareInvesting',
  });
}


// =============================================================================
// 3. FACEBOOK PAGE AUTO-POSTING (Server-side)
// =============================================================================

// This goes in your backend API
// src/services/FacebookPageService.ts

import axios from 'axios';

const FACEBOOK_PAGE_ID = process.env.FACEBOOK_PAGE_ID;
const FACEBOOK_PAGE_ACCESS_TOKEN = process.env.FACEBOOK_PAGE_ACCESS_TOKEN;

interface FacebookPostOptions {
  message: string;
  link?: string;
  imageUrl?: string;
}

export async function postToFacebookPage(options: FacebookPostOptions) {
  const { message, link, imageUrl } = options;
  
  try {
    // Text post with link
    if (link && !imageUrl) {
      const response = await axios.post(
        `https://graph.facebook.com/v18.0/${FACEBOOK_PAGE_ID}/feed`,
        {
          message,
          link,
          access_token: FACEBOOK_PAGE_ACCESS_TOKEN,
        }
      );
      return response.data;
    }
    
    // Photo post
    if (imageUrl) {
      const response = await axios.post(
        `https://graph.facebook.com/v18.0/${FACEBOOK_PAGE_ID}/photos`,
        {
          caption: message,
          url: imageUrl,
          access_token: FACEBOOK_PAGE_ACCESS_TOKEN,
        }
      );
      return response.data;
    }
    
    // Text-only post
    const response = await axios.post(
      `https://graph.facebook.com/v18.0/${FACEBOOK_PAGE_ID}/feed`,
      {
        message,
        access_token: FACEBOOK_PAGE_ACCESS_TOKEN,
      }
    );
    return response.data;
    
  } catch (error) {
    console.error('Facebook post error:', error);
    throw error;
  }
}

// Auto-post new deals to Facebook Page
export async function shareNewDealToPage(deal: {
  title: string;
  companyName: string;
  description: string;
  sector: string;
  stage: string;
  id: number;
}) {
  const message = `🚀 New Investment Opportunity on MedInvest!

${deal.companyName}: ${deal.title}

${deal.description.substring(0, 200)}...

💼 Sector: ${deal.sector}
📈 Stage: ${deal.stage}

Join MedInvest to learn more and express interest.

#HealthcareInvesting #${deal.sector.replace(/\s+/g, '')} #MedInvest`;

  return postToFacebookPage({
    message,
    link: `https://medinvest.com/deals/${deal.id}`,
  });
}

// Auto-post trending discussions
export async function shareTrendingPostToPage(post: {
  content: string;
  authorName: string;
  likesCount: number;
  id: number;
}) {
  const message = `🔥 Trending on MedInvest

"${post.content.substring(0, 280)}${post.content.length > 280 ? '...' : ''}"

- ${post.authorName}

❤️ ${post.likesCount} healthcare professionals engaged

Join the discussion on MedInvest!

#HealthcareCommunity #MedInvest`;

  return postToFacebookPage({
    message,
    link: `https://medinvest.com/posts/${post.id}`,
  });
}


// =============================================================================
// 4. FACEBOOK PIXEL (Tracking & Conversions)
// =============================================================================

// components/FacebookPixel.tsx
'use client';

import Script from 'next/script';
import { usePathname, useSearchParams } from 'next/navigation';
import { useEffect } from 'react';

const FB_PIXEL_ID = process.env.NEXT_PUBLIC_FACEBOOK_PIXEL_ID;

declare global {
  interface Window {
    fbq: any;
    _fbq: any;
  }
}

export function FacebookPixel() {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  useEffect(() => {
    if (typeof window.fbq === 'function') {
      window.fbq('track', 'PageView');
    }
  }, [pathname, searchParams]);

  return (
    <>
      <Script id="facebook-pixel" strategy="afterInteractive">
        {`
          !function(f,b,e,v,n,t,s)
          {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
          n.callMethod.apply(n,arguments):n.queue.push(arguments)};
          if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
          n.queue=[];t=b.createElement(e);t.async=!0;
          t.src=v;s=b.getElementsByTagName(e)[0];
          s.parentNode.insertBefore(t,s)}(window, document,'script',
          'https://connect.facebook.net/en_US/fbevents.js');
          fbq('init', '${FB_PIXEL_ID}');
          fbq('track', 'PageView');
        `}
      </Script>
      <noscript>
        <img
          height="1"
          width="1"
          style={{ display: 'none' }}
          src={`https://www.facebook.com/tr?id=${FB_PIXEL_ID}&ev=PageView&noscript=1`}
          alt=""
        />
      </noscript>
    </>
  );
}

// Track custom events
export const fbTrack = {
  // User signed up
  completeRegistration: (method: string) => {
    if (typeof window.fbq === 'function') {
      window.fbq('track', 'CompleteRegistration', {
        content_name: 'MedInvest Signup',
        method,
      });
    }
  },
  
  // User viewed a deal
  viewContent: (deal: { id: number; title: string; sector: string }) => {
    if (typeof window.fbq === 'function') {
      window.fbq('track', 'ViewContent', {
        content_ids: [deal.id],
        content_name: deal.title,
        content_category: deal.sector,
        content_type: 'deal',
      });
    }
  },
  
  // User expressed interest in deal
  initiateCheckout: (deal: { id: number; title: string; value: number }) => {
    if (typeof window.fbq === 'function') {
      window.fbq('track', 'InitiateCheckout', {
        content_ids: [deal.id],
        content_name: deal.title,
        value: deal.value,
        currency: 'USD',
      });
    }
  },
  
  // User subscribed to premium
  purchase: (plan: string, value: number) => {
    if (typeof window.fbq === 'function') {
      window.fbq('track', 'Purchase', {
        content_name: `Premium ${plan}`,
        value,
        currency: 'USD',
      });
    }
  },
  
  // User started a conversation
  contact: () => {
    if (typeof window.fbq === 'function') {
      window.fbq('track', 'Contact');
    }
  },
  
  // Custom event for lead generation
  lead: (source: string) => {
    if (typeof window.fbq === 'function') {
      window.fbq('track', 'Lead', {
        content_name: source,
      });
    }
  },
};


// =============================================================================
// 5. FACEBOOK MESSENGER CHAT PLUGIN
// =============================================================================

// components/MessengerChat.tsx
'use client';

import Script from 'next/script';

const FB_PAGE_ID = process.env.NEXT_PUBLIC_FACEBOOK_PAGE_ID;

export function MessengerChat() {
  return (
    <>
      <div id="fb-root"></div>
      <div id="fb-customer-chat" className="fb-customerchat"></div>
      
      <Script id="messenger-chat" strategy="lazyOnload">
        {`
          var chatbox = document.getElementById('fb-customer-chat');
          chatbox.setAttribute("page_id", "${FB_PAGE_ID}");
          chatbox.setAttribute("attribution", "biz_inbox");

          window.fbAsyncInit = function() {
            FB.init({
              xfbml: true,
              version: 'v18.0'
            });
          };

          (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
            fjs.parentNode.insertBefore(js, fjs);
          }(document, 'script', 'facebook-jssdk'));
        `}
      </Script>
    </>
  );
}


// =============================================================================
// 6. FACEBOOK SOCIAL PLUGINS
// =============================================================================

// components/FacebookPlugins.tsx

// Like Button
export function FacebookLikeButton({ url }: { url: string }) {
  return (
    <div
      className="fb-like"
      data-href={url}
      data-width=""
      data-layout="button_count"
      data-action="like"
      data-size="small"
      data-share="true"
    />
  );
}

// Page Plugin (embed your FB page)
export function FacebookPageEmbed({ 
  pageUrl,
  width = 340,
  height = 500,
  showFaces = true,
}: {
  pageUrl: string;
  width?: number;
  height?: number;
  showFaces?: boolean;
}) {
  return (
    <div
      className="fb-page"
      data-href={pageUrl}
      data-tabs="timeline"
      data-width={width}
      data-height={height}
      data-small-header="false"
      data-adapt-container-width="true"
      data-hide-cover="false"
      data-show-facepile={showFaces}
    />
  );
}

// Comments Plugin
export function FacebookComments({ 
  url, 
  numPosts = 5 
}: { 
  url: string; 
  numPosts?: number;
}) {
  return (
    <div
      className="fb-comments"
      data-href={url}
      data-width="100%"
      data-numposts={numPosts}
    />
  );
}

// SDK initialization (add to layout)
export function FacebookSDK() {
  return (
    <Script id="facebook-sdk" strategy="lazyOnload">
      {`
        (function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v18.0&appId=${process.env.NEXT_PUBLIC_FACEBOOK_APP_ID}";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
      `}
    </Script>
  );
}
