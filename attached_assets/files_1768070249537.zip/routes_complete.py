"""
Complete MedInvest Platform Routes
All API endpoints and page routes for the full platform
"""
from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from functools import wraps
import stripe
import os

from app import db
from models_complete import (
    User, SubscriptionTier, Subscription, Payment,
    ExpertAMA, AMAQuestion, AMARegistration, AMAStatus,
    InvestmentDeal, DealInterest, DealStatus,
    Mentorship, MentorshipSession, MentorshipStatus,
    Course, CourseModule, CourseEnrollment,
    Event, EventSession, EventRegistration,
    Referral, PortfolioConnection, PortfolioSnapshot
)

# Initialize Stripe
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')

# Create blueprints
ama_bp = Blueprint('ama', __name__, url_prefix='/ama')
deals_bp = Blueprint('deals', __name__, url_prefix='/deals')
subscription_bp = Blueprint('subscription', __name__, url_prefix='/subscription')
mentorship_bp = Blueprint('mentorship', __name__, url_prefix='/mentorship')
courses_bp = Blueprint('courses', __name__, url_prefix='/courses')
events_bp = Blueprint('events', __name__, url_prefix='/events')
referral_bp = Blueprint('referral', __name__, url_prefix='/referral')
portfolio_bp = Blueprint('portfolio', __name__, url_prefix='/portfolio')
ai_bp = Blueprint('ai', __name__, url_prefix='/ai')


# ============================================================================
# DECORATORS
# ============================================================================

def premium_required(f):
    """Decorator to require premium subscription"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if not current_user.is_premium:
            flash('This feature requires a premium subscription.', 'warning')
            return redirect(url_for('subscription.pricing'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """Decorator to require admin role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not getattr(current_user, 'is_admin', False):
            abort(403)
        return f(*args, **kwargs)
    return decorated_function


# ============================================================================
# EXPERT AMAs
# ============================================================================

@ama_bp.route('/')
def list_amas():
    """List all AMAs - upcoming, live, and past"""
    now = datetime.utcnow()
    
    upcoming = ExpertAMA.query.filter(
        ExpertAMA.scheduled_for > now,
        ExpertAMA.status == AMAStatus.SCHEDULED
    ).order_by(ExpertAMA.scheduled_for.asc()).limit(10).all()
    
    live = ExpertAMA.query.filter(
        ExpertAMA.status == AMAStatus.LIVE
    ).all()
    
    past = ExpertAMA.query.filter(
        ExpertAMA.status == AMAStatus.ENDED,
        ExpertAMA.recording_url.isnot(None)
    ).order_by(ExpertAMA.scheduled_for.desc()).limit(20).all()
    
    user_registrations = []
    if current_user.is_authenticated:
        user_registrations = [r.ama_id for r in current_user.ama_registrations]
    
    return render_template('ama/list.html',
                         upcoming=upcoming,
                         live=live,
                         past=past,
                         user_registrations=user_registrations)


@ama_bp.route('/<int:ama_id>')
def view_ama(ama_id):
    """View single AMA details"""
    ama = ExpertAMA.query.get_or_404(ama_id)
    
    is_registered = False
    if current_user.is_authenticated:
        is_registered = AMARegistration.query.filter_by(
            ama_id=ama_id, user_id=current_user.id
        ).first() is not None
    
    questions = AMAQuestion.query.filter_by(ama_id=ama_id)\
        .order_by(AMAQuestion.upvotes.desc())\
        .limit(50).all()
    
    return render_template('ama/detail.html',
                         ama=ama,
                         questions=questions,
                         is_registered=is_registered)


@ama_bp.route('/<int:ama_id>/register', methods=['POST'])
@login_required
def register_ama(ama_id):
    """Register for an AMA"""
    ama = ExpertAMA.query.get_or_404(ama_id)
    
    if ama.is_premium_only and not current_user.is_premium:
        return jsonify({'error': 'Premium subscription required'}), 403
    
    existing = AMARegistration.query.filter_by(
        ama_id=ama_id, user_id=current_user.id
    ).first()
    
    if existing:
        return jsonify({'error': 'Already registered'}), 400
    
    if ama.max_participants and ama.participant_count >= ama.max_participants:
        return jsonify({'error': 'AMA is full'}), 400
    
    registration = AMARegistration(ama_id=ama_id, user_id=current_user.id)
    ama.participant_count += 1
    
    db.session.add(registration)
    db.session.commit()
    
    current_user.points += 10
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Successfully registered!',
        'participant_count': ama.participant_count
    })


@ama_bp.route('/<int:ama_id>/question', methods=['POST'])
@login_required
def ask_question(ama_id):
    """Submit a question for the AMA"""
    ama = ExpertAMA.query.get_or_404(ama_id)
    
    registration = AMARegistration.query.filter_by(
        ama_id=ama_id, user_id=current_user.id
    ).first()
    
    if not registration:
        return jsonify({'error': 'Must be registered to ask questions'}), 403
    
    data = request.get_json()
    question_text = data.get('question', '').strip()
    is_anonymous = data.get('is_anonymous', False)
    
    if not question_text or len(question_text) < 10:
        return jsonify({'error': 'Question too short'}), 400
    
    if len(question_text) > 1000:
        return jsonify({'error': 'Question too long (max 1000 chars)'}), 400
    
    question = AMAQuestion(
        ama_id=ama_id,
        user_id=current_user.id,
        question=question_text,
        is_anonymous=is_anonymous
    )
    
    ama.question_count += 1
    
    db.session.add(question)
    db.session.commit()
    
    current_user.points += 5
    db.session.commit()
    
    return jsonify({
        'success': True,
        'question_id': question.id,
        'message': 'Question submitted!'
    })


@ama_bp.route('/question/<int:question_id>/upvote', methods=['POST'])
@login_required
def upvote_question(question_id):
    """Upvote a question"""
    question = AMAQuestion.query.get_or_404(question_id)
    question.upvotes += 1
    db.session.commit()
    
    return jsonify({'success': True, 'upvotes': question.upvotes})


@ama_bp.route('/<int:ama_id>/live')
@login_required
def live_ama(ama_id):
    """Live AMA interface"""
    ama = ExpertAMA.query.get_or_404(ama_id)
    
    registration = AMARegistration.query.filter_by(
        ama_id=ama_id, user_id=current_user.id
    ).first()
    
    if not registration:
        flash('You must register to join this AMA', 'warning')
        return redirect(url_for('ama.view_ama', ama_id=ama_id))
    
    registration.attended = True
    db.session.commit()
    
    questions = AMAQuestion.query.filter_by(ama_id=ama_id)\
        .order_by(AMAQuestion.upvotes.desc()).all()
    
    return render_template('ama/live.html', ama=ama, questions=questions)


# ============================================================================
# DEAL FLOW / INVESTMENT MARKETPLACE
# ============================================================================

@deals_bp.route('/')
@login_required
def list_deals():
    """List active investment deals"""
    deal_type = request.args.get('type')
    min_investment = request.args.get('min_investment', type=float)
    
    query = InvestmentDeal.query.filter(InvestmentDeal.status == DealStatus.ACTIVE)
    
    if deal_type:
        query = query.filter(InvestmentDeal.deal_type == deal_type)
    
    if min_investment:
        query = query.filter(InvestmentDeal.minimum_investment <= min_investment)
    
    deals = query.order_by(
        InvestmentDeal.is_featured.desc(),
        InvestmentDeal.created_at.desc()
    ).all()
    
    user_interests = []
    if current_user.is_authenticated:
        user_interests = [i.deal_id for i in current_user.deal_interests]
    
    return render_template('deals/list.html',
                         deals=deals,
                         user_interests=user_interests,
                         deal_types=['real_estate', 'fund', 'practice', 'syndicate'])


@deals_bp.route('/<int:deal_id>')
@login_required
def view_deal(deal_id):
    """View deal details"""
    deal = InvestmentDeal.query.get_or_404(deal_id)
    
    deal.view_count += 1
    db.session.commit()
    
    user_interest = DealInterest.query.filter_by(
        deal_id=deal_id, user_id=current_user.id
    ).first()
    
    return render_template('deals/detail.html', deal=deal, user_interest=user_interest)


@deals_bp.route('/<int:deal_id>/interest', methods=['POST'])
@login_required
def express_interest(deal_id):
    """Express interest in a deal"""
    deal = InvestmentDeal.query.get_or_404(deal_id)
    
    existing = DealInterest.query.filter_by(
        deal_id=deal_id, user_id=current_user.id
    ).first()
    
    if existing:
        return jsonify({'error': 'Already expressed interest'}), 400
    
    data = request.get_json()
    
    interest = DealInterest(
        deal_id=deal_id,
        user_id=current_user.id,
        investment_amount=data.get('investment_amount'),
        message=data.get('message')
    )
    
    deal.interest_count += 1
    
    db.session.add(interest)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Interest submitted! The sponsor will contact you.'
    })


@deals_bp.route('/submit', methods=['GET', 'POST'])
@login_required
@premium_required
def submit_deal():
    """Submit a new deal for review"""
    if request.method == 'GET':
        return render_template('deals/submit.html')
    
    data = request.form
    
    deal = InvestmentDeal(
        title=data.get('title'),
        description=data.get('description'),
        deal_type=data.get('deal_type'),
        minimum_investment=float(data.get('minimum_investment', 0)),
        target_raise=float(data.get('target_raise', 0)) if data.get('target_raise') else None,
        projected_return=data.get('projected_return'),
        investment_term=data.get('investment_term'),
        accredited_only=data.get('accredited_only') == 'on',
        physician_only=data.get('physician_only') == 'on',
        sponsor_name=data.get('sponsor_name'),
        sponsor_bio=data.get('sponsor_bio'),
        sponsor_contact=data.get('sponsor_contact'),
        location=data.get('location'),
        status=DealStatus.REVIEW
    )
    
    db.session.add(deal)
    db.session.commit()
    
    flash('Deal submitted for review!', 'success')
    return redirect(url_for('deals.list_deals'))


# ============================================================================
# SUBSCRIPTIONS & PAYMENTS
# ============================================================================

STRIPE_PRICES = {
    'premium_monthly': os.environ.get('STRIPE_PRICE_MONTHLY', 'price_monthly'),
    'premium_yearly': os.environ.get('STRIPE_PRICE_YEARLY', 'price_yearly')
}


@subscription_bp.route('/pricing')
def pricing():
    """Show pricing page"""
    return render_template('subscription/pricing.html')


@subscription_bp.route('/checkout/<plan>')
@login_required
def checkout(plan):
    """Create Stripe checkout session"""
    if plan not in ['monthly', 'yearly']:
        abort(400)
    
    price_id = STRIPE_PRICES[f'premium_{plan}']
    
    try:
        if not current_user.stripe_customer_id:
            customer = stripe.Customer.create(
                email=current_user.email,
                name=current_user.full_name,
                metadata={'user_id': current_user.id}
            )
            current_user.stripe_customer_id = customer.id
            db.session.commit()
        
        checkout_session = stripe.checkout.Session.create(
            customer=current_user.stripe_customer_id,
            payment_method_types=['card'],
            line_items=[{'price': price_id, 'quantity': 1}],
            mode='subscription',
            success_url=url_for('subscription.success', _external=True) + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=url_for('subscription.pricing', _external=True),
            metadata={'user_id': current_user.id}
        )
        
        return redirect(checkout_session.url)
    
    except stripe.error.StripeError as e:
        flash(f'Error: {str(e)}', 'error')
        return redirect(url_for('subscription.pricing'))


@subscription_bp.route('/success')
@login_required
def success():
    """Handle successful subscription"""
    session_id = request.args.get('session_id')
    
    if session_id:
        try:
            session = stripe.checkout.Session.retrieve(session_id)
            subscription = stripe.Subscription.retrieve(session.subscription)
            
            current_user.subscription_tier = SubscriptionTier.PREMIUM
            current_user.subscription_ends_at = datetime.fromtimestamp(
                subscription.current_period_end
            )
            
            sub_record = Subscription(
                user_id=current_user.id,
                tier=SubscriptionTier.PREMIUM,
                stripe_subscription_id=subscription.id,
                amount=subscription.plan.amount / 100,
                interval=subscription.plan.interval,
                status=subscription.status,
                current_period_start=datetime.fromtimestamp(subscription.current_period_start),
                current_period_end=datetime.fromtimestamp(subscription.current_period_end)
            )
            
            db.session.add(sub_record)
            db.session.commit()
            
            current_user.points += 500
            db.session.commit()
            
        except stripe.error.StripeError as e:
            flash(f'Error verifying subscription: {str(e)}', 'error')
    
    flash('Welcome to Premium! 🎉', 'success')
    return redirect(url_for('main.dashboard'))


@subscription_bp.route('/webhook', methods=['POST'])
def webhook():
    """Handle Stripe webhooks"""
    payload = request.get_data()
    sig_header = request.headers.get('Stripe-Signature')
    webhook_secret = os.environ.get('STRIPE_WEBHOOK_SECRET')
    
    try:
        event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
    except (ValueError, stripe.error.SignatureVerificationError):
        return '', 400
    
    if event['type'] == 'customer.subscription.updated':
        handle_subscription_update(event['data']['object'])
    elif event['type'] == 'customer.subscription.deleted':
        handle_subscription_cancelled(event['data']['object'])
    elif event['type'] == 'invoice.payment_succeeded':
        handle_payment_succeeded(event['data']['object'])
    elif event['type'] == 'invoice.payment_failed':
        handle_payment_failed(event['data']['object'])
    
    return '', 200


def handle_subscription_update(subscription):
    """Handle subscription updates from Stripe"""
    sub_record = Subscription.query.filter_by(
        stripe_subscription_id=subscription.id
    ).first()
    
    if sub_record:
        sub_record.status = subscription.status
        sub_record.current_period_end = datetime.fromtimestamp(subscription.current_period_end)
        sub_record.cancel_at_period_end = subscription.cancel_at_period_end
        
        user = User.query.get(sub_record.user_id)
        if user:
            user.subscription_ends_at = sub_record.current_period_end
        
        db.session.commit()


def handle_subscription_cancelled(subscription):
    """Handle subscription cancellation"""
    sub_record = Subscription.query.filter_by(
        stripe_subscription_id=subscription.id
    ).first()
    
    if sub_record:
        sub_record.status = 'cancelled'
        
        user = User.query.get(sub_record.user_id)
        if user:
            user.subscription_tier = SubscriptionTier.FREE
            user.subscription_ends_at = None
        
        db.session.commit()


def handle_payment_succeeded(invoice):
    """Record successful payment"""
    customer_id = invoice.customer
    user = User.query.filter_by(stripe_customer_id=customer_id).first()
    
    if user:
        payment = Payment(
            user_id=user.id,
            stripe_payment_intent_id=invoice.payment_intent,
            amount=invoice.amount_paid / 100,
            status='succeeded',
            payment_type='subscription'
        )
        db.session.add(payment)
        db.session.commit()


def handle_payment_failed(invoice):
    """Handle failed payment"""
    pass  # Send notification email


@subscription_bp.route('/cancel', methods=['POST'])
@login_required
def cancel_subscription():
    """Cancel subscription at period end"""
    sub = Subscription.query.filter_by(user_id=current_user.id, status='active').first()
    
    if not sub:
        return jsonify({'error': 'No active subscription'}), 400
    
    try:
        stripe.Subscription.modify(sub.stripe_subscription_id, cancel_at_period_end=True)
        sub.cancel_at_period_end = True
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Subscription will end on {sub.current_period_end.strftime("%B %d, %Y")}'
        })
    except stripe.error.StripeError as e:
        return jsonify({'error': str(e)}), 400


@subscription_bp.route('/manage')
@login_required
def manage():
    """Subscription management page"""
    subscriptions = Subscription.query.filter_by(user_id=current_user.id)\
        .order_by(Subscription.created_at.desc()).all()
    
    payments = Payment.query.filter_by(user_id=current_user.id)\
        .order_by(Payment.created_at.desc()).limit(10).all()
    
    return render_template('subscription/manage.html',
                         subscriptions=subscriptions,
                         payments=payments)


# ============================================================================
# MENTORSHIP
# ============================================================================

@mentorship_bp.route('/')
@login_required
def index():
    """Mentorship program landing page"""
    mentors = User.query.filter(
        User.id != current_user.id,
        User.years_of_experience >= 5,
        User.is_verified == True
    ).order_by(User.points.desc()).limit(20).all()
    
    as_mentor = current_user.mentorships_as_mentor.filter(
        Mentorship.status.in_([MentorshipStatus.PENDING, MentorshipStatus.ACTIVE])
    ).all()
    
    as_mentee = current_user.mentorships_as_mentee.filter(
        Mentorship.status.in_([MentorshipStatus.PENDING, MentorshipStatus.ACTIVE])
    ).all()
    
    return render_template('mentorship/index.html',
                         mentors=mentors,
                         as_mentor=as_mentor,
                         as_mentee=as_mentee)


@mentorship_bp.route('/request/<int:mentor_id>', methods=['POST'])
@login_required
def request_mentor(mentor_id):
    """Request mentorship from a user"""
    mentor = User.query.get_or_404(mentor_id)
    
    if mentor.id == current_user.id:
        return jsonify({'error': 'Cannot mentor yourself'}), 400
    
    existing = Mentorship.query.filter_by(
        mentor_id=mentor_id,
        mentee_id=current_user.id,
        status=MentorshipStatus.ACTIVE
    ).first()
    
    if existing:
        return jsonify({'error': 'Already have active mentorship'}), 400
    
    data = request.get_json()
    
    mentorship = Mentorship(
        mentor_id=mentor_id,
        mentee_id=current_user.id,
        focus_areas=data.get('focus_areas'),
        duration_months=data.get('duration_months', 3),
        status=MentorshipStatus.PENDING
    )
    
    db.session.add(mentorship)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Mentorship request sent!'})


@mentorship_bp.route('/<int:mentorship_id>/accept', methods=['POST'])
@login_required
def accept_mentorship(mentorship_id):
    """Accept a mentorship request"""
    mentorship = Mentorship.query.get_or_404(mentorship_id)
    
    if mentorship.mentor_id != current_user.id:
        abort(403)
    
    mentorship.status = MentorshipStatus.ACTIVE
    mentorship.start_date = datetime.utcnow()
    mentorship.end_date = datetime.utcnow() + timedelta(days=30 * mentorship.duration_months)
    
    db.session.commit()
    
    current_user.points += 100
    mentorship.mentee.points += 50
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Mentorship accepted!'})


@mentorship_bp.route('/<int:mentorship_id>/session', methods=['POST'])
@login_required
def schedule_session(mentorship_id):
    """Schedule a mentorship session"""
    mentorship = Mentorship.query.get_or_404(mentorship_id)
    
    if current_user.id not in [mentorship.mentor_id, mentorship.mentee_id]:
        abort(403)
    
    data = request.get_json()
    
    session = MentorshipSession(
        mentorship_id=mentorship_id,
        scheduled_for=datetime.fromisoformat(data.get('scheduled_for')),
        duration_minutes=data.get('duration_minutes', 30)
    )
    
    db.session.add(session)
    db.session.commit()
    
    return jsonify({'success': True, 'session_id': session.id})


@mentorship_bp.route('/session/<int:session_id>/complete', methods=['POST'])
@login_required
def complete_session(session_id):
    """Mark session as completed"""
    session = MentorshipSession.query.get_or_404(session_id)
    mentorship = session.mentorship
    
    if current_user.id not in [mentorship.mentor_id, mentorship.mentee_id]:
        abort(403)
    
    data = request.get_json()
    
    session.completed = True
    session.completed_at = datetime.utcnow()
    session.topics_discussed = data.get('topics_discussed')
    session.action_items = data.get('action_items')
    session.notes = data.get('notes')
    
    mentorship.total_meetings += 1
    mentorship.last_meeting = datetime.utcnow()
    
    db.session.commit()
    
    mentorship.mentor.points += 25
    mentorship.mentee.points += 15
    db.session.commit()
    
    return jsonify({'success': True})


# ============================================================================
# COURSES
# ============================================================================

@courses_bp.route('/')
def list_courses():
    """List all published courses"""
    courses = Course.query.filter_by(is_published=True)\
        .order_by(Course.is_featured.desc(), Course.enrolled_count.desc()).all()
    
    user_enrollments = []
    if current_user.is_authenticated:
        user_enrollments = [e.course_id for e in current_user.course_enrollments]
    
    return render_template('courses/list.html',
                         courses=courses,
                         user_enrollments=user_enrollments)


@courses_bp.route('/<int:course_id>')
def view_course(course_id):
    """View course details"""
    course = Course.query.get_or_404(course_id)
    
    enrollment = None
    if current_user.is_authenticated:
        enrollment = CourseEnrollment.query.filter_by(
            course_id=course_id, user_id=current_user.id
        ).first()
    
    modules = course.modules.order_by(CourseModule.order_index).all()
    
    return render_template('courses/detail.html',
                         course=course,
                         modules=modules,
                         enrollment=enrollment)


@courses_bp.route('/<int:course_id>/enroll', methods=['POST'])
@login_required
def enroll_course(course_id):
    """Enroll in a course (purchase)"""
    course = Course.query.get_or_404(course_id)
    
    existing = CourseEnrollment.query.filter_by(
        course_id=course_id, user_id=current_user.id
    ).first()
    
    if existing:
        return jsonify({'error': 'Already enrolled'}), 400
    
    price = course.price
    if current_user.is_premium:
        price = price * 0.8
    
    try:
        checkout_session = stripe.checkout.Session.create(
            customer=current_user.stripe_customer_id,
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': course.title,
                        'description': f'Course enrollment - {course.total_modules} modules'
                    },
                    'unit_amount': int(price * 100)
                },
                'quantity': 1
            }],
            mode='payment',
            success_url=url_for('courses.enroll_success', course_id=course_id, _external=True) + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=url_for('courses.view_course', course_id=course_id, _external=True),
            metadata={'user_id': current_user.id, 'course_id': course_id}
        )
        
        return jsonify({'success': True, 'checkout_url': checkout_session.url})
    
    except stripe.error.StripeError as e:
        return jsonify({'error': str(e)}), 400


@courses_bp.route('/<int:course_id>/enroll/success')
@login_required
def enroll_success(course_id):
    """Handle successful course enrollment"""
    course = Course.query.get_or_404(course_id)
    session_id = request.args.get('session_id')
    
    if session_id:
        try:
            session = stripe.checkout.Session.retrieve(session_id)
            
            enrollment = CourseEnrollment(
                course_id=course_id,
                user_id=current_user.id,
                purchase_price=session.amount_total / 100,
                completed_modules=[]
            )
            
            course.enrolled_count += 1
            
            db.session.add(enrollment)
            db.session.commit()
            
            current_user.points += 50
            db.session.commit()
            
        except stripe.error.StripeError as e:
            flash(f'Error: {str(e)}', 'error')
    
    flash('Successfully enrolled! Let\'s start learning.', 'success')
    return redirect(url_for('courses.learn', course_id=course_id))


@courses_bp.route('/<int:course_id>/learn')
@login_required
def learn(course_id):
    """Course learning interface"""
    course = Course.query.get_or_404(course_id)
    
    enrollment = CourseEnrollment.query.filter_by(
        course_id=course_id, user_id=current_user.id
    ).first()
    
    if not enrollment:
        flash('Please enroll first', 'warning')
        return redirect(url_for('courses.view_course', course_id=course_id))
    
    modules = course.modules.order_by(CourseModule.order_index).all()
    
    module_id = request.args.get('module', type=int)
    current_module = None
    
    if module_id:
        current_module = CourseModule.query.get(module_id)
    elif modules:
        completed = enrollment.completed_modules or []
        for m in modules:
            if m.id not in completed:
                current_module = m
                break
        if not current_module:
            current_module = modules[0]
    
    return render_template('courses/learn.html',
                         course=course,
                         modules=modules,
                         current_module=current_module,
                         enrollment=enrollment)


@courses_bp.route('/<int:course_id>/module/<int:module_id>/complete', methods=['POST'])
@login_required
def complete_module(course_id, module_id):
    """Mark module as completed"""
    enrollment = CourseEnrollment.query.filter_by(
        course_id=course_id, user_id=current_user.id
    ).first()
    
    if not enrollment:
        return jsonify({'error': 'Not enrolled'}), 403
    
    completed = enrollment.completed_modules or []
    if module_id not in completed:
        completed.append(module_id)
        enrollment.completed_modules = completed
        
        course = Course.query.get(course_id)
        enrollment.progress_percent = (len(completed) / course.total_modules) * 100
        
        if enrollment.progress_percent >= 100:
            enrollment.completed = True
            enrollment.completed_at = datetime.utcnow()
            current_user.points += 200
        else:
            current_user.points += 10
        
        db.session.commit()
    
    return jsonify({'success': True, 'progress': enrollment.progress_percent})


# ============================================================================
# EVENTS
# ============================================================================

@events_bp.route('/')
def list_events():
    """List upcoming events"""
    now = datetime.utcnow()
    
    upcoming = Event.query.filter(
        Event.start_date > now,
        Event.is_published == True
    ).order_by(Event.start_date.asc()).all()
    
    past = Event.query.filter(
        Event.end_date < now,
        Event.is_published == True
    ).order_by(Event.start_date.desc()).limit(10).all()
    
    return render_template('events/list.html', upcoming=upcoming, past=past)


@events_bp.route('/<int:event_id>')
def view_event(event_id):
    """View event details"""
    event = Event.query.get_or_404(event_id)
    
    sessions = event.sessions.order_by(EventSession.start_time).all()
    
    registration = None
    if current_user.is_authenticated:
        registration = EventRegistration.query.filter_by(
            event_id=event_id, user_id=current_user.id
        ).first()
    
    now = datetime.utcnow()
    if event.early_bird_ends and now < event.early_bird_ends:
        current_price = event.early_bird_price
        is_early_bird = True
    else:
        current_price = event.regular_price
        is_early_bird = False
    
    return render_template('events/detail.html',
                         event=event,
                         sessions=sessions,
                         registration=registration,
                         current_price=current_price,
                         is_early_bird=is_early_bird)


@events_bp.route('/<int:event_id>/register', methods=['POST'])
@login_required
def register_event(event_id):
    """Register for an event"""
    event = Event.query.get_or_404(event_id)
    
    if event.max_attendees and event.current_attendees >= event.max_attendees:
        return jsonify({'error': 'Event is full'}), 400
    
    data = request.get_json()
    ticket_type = data.get('ticket_type', 'regular')
    
    now = datetime.utcnow()
    if ticket_type == 'vip' and event.vip_price:
        price = event.vip_price
    elif event.early_bird_ends and now < event.early_bird_ends:
        price = event.early_bird_price
    else:
        price = event.regular_price
    
    if current_user.is_premium:
        price = price * 0.85
    
    try:
        checkout_session = stripe.checkout.Session.create(
            customer=current_user.stripe_customer_id,
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {'name': f'{event.title} - {ticket_type.title()} Ticket'},
                    'unit_amount': int(price * 100)
                },
                'quantity': 1
            }],
            mode='payment',
            success_url=url_for('events.register_success', event_id=event_id, _external=True) + f'?session_id={{CHECKOUT_SESSION_ID}}&ticket_type={ticket_type}',
            cancel_url=url_for('events.view_event', event_id=event_id, _external=True),
            metadata={'user_id': current_user.id, 'event_id': event_id, 'ticket_type': ticket_type}
        )
        
        return jsonify({'success': True, 'checkout_url': checkout_session.url})
    
    except stripe.error.StripeError as e:
        return jsonify({'error': str(e)}), 400


@events_bp.route('/<int:event_id>/register/success')
@login_required
def register_success(event_id):
    """Handle successful event registration"""
    event = Event.query.get_or_404(event_id)
    session_id = request.args.get('session_id')
    ticket_type = request.args.get('ticket_type', 'regular')
    
    if session_id:
        try:
            session = stripe.checkout.Session.retrieve(session_id)
            
            registration = EventRegistration(
                event_id=event_id,
                user_id=current_user.id,
                ticket_type=ticket_type,
                purchase_price=session.amount_total / 100
            )
            
            event.current_attendees += 1
            
            db.session.add(registration)
            db.session.commit()
            
            current_user.points += 25
            db.session.commit()
            
        except stripe.error.StripeError as e:
            flash(f'Error: {str(e)}', 'error')
    
    flash('You\'re registered! See you there.', 'success')
    return redirect(url_for('events.view_event', event_id=event_id))


# ============================================================================
# REFERRAL PROGRAM
# ============================================================================

@referral_bp.route('/')
@login_required
def index():
    """Referral program dashboard"""
    if not current_user.referral_code:
        current_user.generate_referral_code()
        db.session.commit()
    
    referrals = Referral.query.filter_by(referrer_id=current_user.id).all()
    
    stats = {
        'total_referrals': len(referrals),
        'activated': sum(1 for r in referrals if r.referred_user_activated),
        'premium_conversions': sum(1 for r in referrals if r.referred_user_premium),
        'total_rewards': sum(r.reward_value or 0 for r in referrals if r.rewarded_at)
    }
    
    return render_template('referral/index.html',
                         referral_code=current_user.referral_code,
                         referrals=referrals,
                         stats=stats)


@referral_bp.route('/apply', methods=['POST'])
@login_required
def apply_referral():
    """Apply a referral code"""
    data = request.get_json()
    code = data.get('code', '').strip().upper()
    
    if not code:
        return jsonify({'error': 'No code provided'}), 400
    
    referrer = User.query.filter_by(referral_code=code).first()
    
    if not referrer:
        return jsonify({'error': 'Invalid referral code'}), 400
    
    if referrer.id == current_user.id:
        return jsonify({'error': 'Cannot use your own code'}), 400
    
    if current_user.referred_by_id:
        return jsonify({'error': 'Already used a referral code'}), 400
    
    current_user.referred_by_id = referrer.id
    
    referral = Referral(
        referrer_id=referrer.id,
        referred_user_id=current_user.id,
        referral_code_used=code,
        status='pending'
    )
    
    db.session.add(referral)
    db.session.commit()
    
    current_user.points += 50
    referrer.points += 100
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Referral code applied! You earned 50 bonus points.'
    })


@referral_bp.route('/check_rewards')
@login_required
def check_rewards():
    """Check and award pending referral rewards"""
    referrals = Referral.query.filter_by(referrer_id=current_user.id, status='pending').all()
    
    rewards_given = 0
    
    for referral in referrals:
        if referral.referred_user:
            if not referral.referred_user_activated:
                post_count = referral.referred_user.posts.count()
                if post_count > 0:
                    referral.referred_user_activated = True
                    current_user.points += 50
                    rewards_given += 1
            
            if not referral.referred_user_premium and referral.referred_user.is_premium:
                referral.referred_user_premium = True
                referral.reward_type = 'premium_month'
                referral.reward_value = 29
                referral.rewarded_at = datetime.utcnow()
                referral.status = 'rewarded'
                
                if current_user.subscription_ends_at:
                    current_user.subscription_ends_at += timedelta(days=30)
                rewards_given += 1
    
    db.session.commit()
    
    return jsonify({'rewards_checked': len(referrals), 'rewards_given': rewards_given})


# ============================================================================
# PORTFOLIO TRACKING
# ============================================================================

@portfolio_bp.route('/')
@login_required
@premium_required
def index():
    """Portfolio dashboard"""
    connections = PortfolioConnection.query.filter_by(
        user_id=current_user.id,
        is_active=True
    ).all()
    
    latest_snapshot = PortfolioSnapshot.query.filter_by(
        user_id=current_user.id
    ).order_by(PortfolioSnapshot.snapshot_date.desc()).first()
    
    snapshots = PortfolioSnapshot.query.filter_by(
        user_id=current_user.id
    ).order_by(PortfolioSnapshot.snapshot_date.asc()).limit(365).all()
    
    return render_template('portfolio/index.html',
                         connections=connections,
                         latest=latest_snapshot,
                         snapshots=snapshots)


@portfolio_bp.route('/connect', methods=['POST'])
@login_required
@premium_required
def connect_account():
    """Connect a brokerage account via Plaid"""
    return jsonify({
        'success': True,
        'message': 'Account connected!',
        'plaid_link_token': 'link-sandbox-xxx'
    })


@portfolio_bp.route('/sync', methods=['POST'])
@login_required
@premium_required
def sync_portfolio():
    """Sync portfolio data from connected accounts"""
    connections = PortfolioConnection.query.filter_by(
        user_id=current_user.id,
        is_active=True
    ).all()
    
    if not connections:
        return jsonify({'error': 'No connected accounts'}), 400
    
    today = datetime.utcnow().date()
    
    existing = PortfolioSnapshot.query.filter_by(
        user_id=current_user.id,
        snapshot_date=today
    ).first()
    
    if existing:
        return jsonify({'message': 'Already synced today'})
    
    snapshot = PortfolioSnapshot(
        user_id=current_user.id,
        snapshot_date=today,
        total_value=500000,
        cash=50000,
        stocks=300000,
        bonds=100000,
        real_estate=50000
    )
    
    db.session.add(snapshot)
    
    for conn in connections:
        conn.last_synced = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'snapshot': {'total_value': snapshot.total_value, 'date': str(snapshot.snapshot_date)}
    })


@portfolio_bp.route('/analysis')
@login_required
@premium_required
def analysis():
    """Portfolio analysis and recommendations"""
    snapshots = PortfolioSnapshot.query.filter_by(
        user_id=current_user.id
    ).order_by(PortfolioSnapshot.snapshot_date.desc()).limit(30).all()
    
    if not snapshots:
        return render_template('portfolio/analysis.html', has_data=False)
    
    latest = snapshots[0]
    
    total = latest.total_value or 1
    allocation = {
        'cash': (latest.cash or 0) / total * 100,
        'stocks': (latest.stocks or 0) / total * 100,
        'bonds': (latest.bonds or 0) / total * 100,
        'real_estate': (latest.real_estate or 0) / total * 100,
        'crypto': (latest.crypto or 0) / total * 100,
        'other': (latest.other or 0) / total * 100
    }
    
    recommendations = []
    
    if allocation['cash'] > 20:
        recommendations.append({
            'type': 'warning',
            'message': 'High cash allocation (>20%). Consider investing excess cash.'
        })
    
    if allocation['bonds'] < 10 and current_user.years_of_experience and current_user.years_of_experience > 20:
        recommendations.append({
            'type': 'info',
            'message': 'Consider increasing bond allocation as you approach retirement.'
        })
    
    if allocation['stocks'] > 80:
        recommendations.append({
            'type': 'info',
            'message': 'Heavy stock allocation. Ensure this matches your risk tolerance.'
        })
    
    return render_template('portfolio/analysis.html',
                         has_data=True,
                         latest=latest,
                         allocation=allocation,
                         recommendations=recommendations,
                         snapshots=snapshots)


# ============================================================================
# AI CHATBOT
# ============================================================================

@ai_bp.route('/')
@login_required
def chat():
    """AI chatbot interface"""
    return render_template('ai/chat.html')


@ai_bp.route('/ask', methods=['POST'])
@login_required
def ask_ai():
    """Ask the AI a question"""
    import anthropic
    
    data = request.get_json()
    question = data.get('question', '').strip()
    
    if not question:
        return jsonify({'error': 'No question provided'}), 400
    
    try:
        client = anthropic.Anthropic(api_key=os.environ.get('ANTHROPIC_API_KEY'))
        
        system_prompt = """You are MedInvest AI, a helpful financial assistant for physicians.
        
        Your role is to:
        - Answer questions about personal finance, investing, and retirement planning
        - Provide general information about tax strategies for high earners
        - Explain investment concepts in simple terms
        - Help with budgeting and debt payoff strategies
        
        Important:
        - You are NOT a financial advisor and cannot give specific investment advice
        - Always recommend consulting a licensed professional for personalized advice
        - Be especially helpful about physician-specific topics (student loans, PSLF, backdoor Roth, etc.)
        - Keep responses concise and actionable
        """
        
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            system=system_prompt,
            messages=[{"role": "user", "content": question}]
        )
        
        response_text = message.content[0].text
        
        current_user.points += 2
        db.session.commit()
        
        return jsonify({'success': True, 'response': response_text})
    
    except Exception as e:
        return jsonify({'error': f'AI service error: {str(e)}'}), 500


# ============================================================================
# ADMIN ROUTES
# ============================================================================

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')


@admin_bp.route('/deals')
@login_required
@admin_required
def manage_deals():
    """Admin: Manage investment deals"""
    pending = InvestmentDeal.query.filter_by(status=DealStatus.REVIEW).all()
    active = InvestmentDeal.query.filter_by(status=DealStatus.ACTIVE).all()
    
    return render_template('admin/deals.html', pending=pending, active=active)


@admin_bp.route('/deals/<int:deal_id>/approve', methods=['POST'])
@login_required
@admin_required
def approve_deal(deal_id):
    """Admin: Approve a deal"""
    deal = InvestmentDeal.query.get_or_404(deal_id)
    deal.status = DealStatus.ACTIVE
    db.session.commit()
    
    return jsonify({'success': True})


@admin_bp.route('/deals/<int:deal_id>/reject', methods=['POST'])
@login_required
@admin_required
def reject_deal(deal_id):
    """Admin: Reject a deal"""
    deal = InvestmentDeal.query.get_or_404(deal_id)
    deal.status = DealStatus.REJECTED
    db.session.commit()
    
    return jsonify({'success': True})


@admin_bp.route('/amas', methods=['GET', 'POST'])
@login_required
@admin_required
def manage_amas():
    """Admin: Create and manage AMAs"""
    if request.method == 'POST':
        data = request.form
        
        ama = ExpertAMA(
            expert_name=data.get('expert_name'),
            expert_title=data.get('expert_title'),
            expert_bio=data.get('expert_bio'),
            title=data.get('title'),
            description=data.get('description'),
            topic_tags=data.get('topic_tags'),
            scheduled_for=datetime.fromisoformat(data.get('scheduled_for')),
            duration_minutes=int(data.get('duration_minutes', 60)),
            is_premium_only=data.get('is_premium_only') == 'on',
            sponsor_name=data.get('sponsor_name'),
            sponsor_logo_url=data.get('sponsor_logo_url')
        )
        
        db.session.add(ama)
        db.session.commit()
        
        flash('AMA created!', 'success')
        return redirect(url_for('admin.manage_amas'))
    
    amas = ExpertAMA.query.order_by(ExpertAMA.scheduled_for.desc()).all()
    return render_template('admin/amas.html', amas=amas)


@admin_bp.route('/analytics')
@login_required
@admin_required
def analytics():
    """Admin: Platform analytics dashboard"""
    from sqlalchemy import func
    
    total_users = User.query.count()
    premium_users = User.query.filter(User.subscription_tier == SubscriptionTier.PREMIUM).count()
    new_users_week = User.query.filter(
        User.created_at >= datetime.utcnow() - timedelta(days=7)
    ).count()
    
    monthly_revenue = db.session.query(func.sum(Payment.amount)).filter(
        Payment.created_at >= datetime.utcnow() - timedelta(days=30),
        Payment.status == 'succeeded'
    ).scalar() or 0
    
    stats = {
        'total_users': total_users,
        'premium_users': premium_users,
        'premium_rate': (premium_users / total_users * 100) if total_users > 0 else 0,
        'new_users_week': new_users_week,
        'monthly_revenue': monthly_revenue
    }
    
    return render_template('admin/analytics.html', stats=stats)


# ============================================================================
# REGISTER ALL BLUEPRINTS
# ============================================================================

def register_blueprints(app):
    """Register all blueprints with the Flask app"""
    app.register_blueprint(ama_bp)
    app.register_blueprint(deals_bp)
    app.register_blueprint(subscription_bp)
    app.register_blueprint(mentorship_bp)
    app.register_blueprint(courses_bp)
    app.register_blueprint(events_bp)
    app.register_blueprint(referral_bp)
    app.register_blueprint(portfolio_bp)
    app.register_blueprint(ai_bp)
    app.register_blueprint(admin_bp)
