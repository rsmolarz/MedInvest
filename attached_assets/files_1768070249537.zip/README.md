# MedInvest - Physician Investment Platform

A comprehensive social investment platform built exclusively for physicians. Features anonymous discussions, expert AMAs, investment deal flow, courses, mentorship, and AI-powered financial assistance.

## 🚀 Features

### Core Platform
- **14 Specialty Rooms** - Investment discussions by specialty, strategy, and career stage
- **Anonymous Posting** - Discuss sensitive financial topics privately
- **Gamification** - Points, levels, streaks, and achievements
- **Verified Physicians** - Medical license verification for all members

### Premium Features ($29/mo or $249/yr)
- **Expert AMAs** - Live Q&A with financial advisors, CPAs, and successful physician investors
- **Deal Flow Marketplace** - Vetted investment opportunities (real estate, syndicates, funds)
- **AI Financial Assistant** - Claude-powered chatbot for investment questions
- **Portfolio Tracking** - Connect accounts via Plaid for analytics
- **Mentorship Program** - 1:1 connections with experienced physician investors
- **Premium Courses** - Deep-dive educational content

### Additional Features
- **Virtual Events** - Conferences and workshops
- **Referral Program** - Earn rewards for inviting colleagues
- **Email Campaigns** - Targeted communications

## 📁 Project Structure

```
medinvest/
├── app.py                 # Main Flask application
├── models_complete.py     # All database models
├── routes_complete.py     # All API routes and blueprints
├── seed_data.py          # Sample data for development
├── config.py             # Configuration settings
├── requirements.txt      # Python dependencies
├── .env.example          # Environment variables template
│
├── templates/
│   ├── base.html         # Base template with navigation
│   ├── index.html        # Landing page
│   ├── feed.html         # Main feed
│   ├── profile.html      # User profile
│   ├── dashboard.html    # User dashboard
│   │
│   ├── auth/
│   │   ├── login.html
│   │   └── register.html
│   │
│   ├── ama/
│   │   ├── list.html     # AMA listings
│   │   ├── detail.html   # Single AMA view
│   │   └── live.html     # Live AMA interface
│   │
│   ├── deals/
│   │   ├── list.html     # Deal marketplace
│   │   ├── detail.html   # Deal details
│   │   └── submit.html   # Submit new deal
│   │
│   ├── subscription/
│   │   ├── pricing.html  # Pricing page
│   │   └── manage.html   # Subscription management
│   │
│   ├── courses/
│   │   ├── list.html     # Course catalog
│   │   ├── detail.html   # Course details
│   │   └── learn.html    # Learning interface
│   │
│   ├── events/
│   │   ├── list.html     # Event listings
│   │   └── detail.html   # Event details
│   │
│   ├── mentorship/
│   │   └── index.html    # Mentorship hub
│   │
│   ├── portfolio/
│   │   ├── index.html    # Portfolio dashboard
│   │   └── analysis.html # Analysis & recommendations
│   │
│   ├── referral/
│   │   └── index.html    # Referral program
│   │
│   ├── ai/
│   │   └── chat.html     # AI chatbot interface
│   │
│   ├── rooms/
│   │   ├── list.html     # Room listings
│   │   └── detail.html   # Room view
│   │
│   ├── admin/
│   │   ├── analytics.html
│   │   ├── deals.html
│   │   └── amas.html
│   │
│   └── errors/
│       ├── 404.html
│       ├── 403.html
│       └── 500.html
```

## 🛠 Installation

### 1. Clone and Setup

```bash
git clone https://github.com/yourusername/medinvest.git
cd medinvest
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your API keys
```

### 3. Initialize Database

```bash
flask db init
flask db migrate
flask db upgrade
flask seed-db  # Optional: add sample data
```

### 4. Run Development Server

```bash
flask run
# Visit http://localhost:5000
```

## 🔑 API Keys Required

| Service | Purpose | Get Key |
|---------|---------|---------|
| Stripe | Payments | https://stripe.com |
| Anthropic | AI Chat | https://anthropic.com |
| Plaid | Portfolio | https://plaid.com |
| SendGrid | Email | https://sendgrid.com |

## 💳 Stripe Setup

1. Create products in Stripe Dashboard:
   - Premium Monthly: $29/month
   - Premium Annual: $249/year

2. Add Price IDs to `.env`:
   ```
   STRIPE_PRICE_MONTHLY=price_xxx
   STRIPE_PRICE_YEARLY=price_xxx
   ```

3. Set up webhook endpoint: `/subscription/webhook`

## 📊 Database Models

### User & Auth
- `User` - Physician accounts with verification, subscription, points/levels

### Content
- `ExpertAMA`, `AMAQuestion`, `AMARegistration`
- `InvestmentDeal`, `DealInterest`
- `Course`, `CourseModule`, `CourseEnrollment`
- `Event`, `EventSession`, `EventRegistration`

### Features
- `Subscription`, `Payment`
- `Mentorship`, `MentorshipSession`
- `Referral`
- `PortfolioConnection`, `PortfolioSnapshot`

## 🚀 Deployment

### Production Checklist
- [ ] Set `FLASK_ENV=production`
- [ ] Use PostgreSQL database
- [ ] Configure proper `SECRET_KEY`
- [ ] Set up SSL/HTTPS
- [ ] Configure Stripe live keys
- [ ] Set up email service
- [ ] Configure CDN for static files
- [ ] Set up error monitoring (Sentry)

### Deploy to Heroku

```bash
heroku create medinvest
heroku addons:create heroku-postgresql:hobby-dev
heroku config:set SECRET_KEY=your-secret-key
# Add other config vars...
git push heroku main
heroku run flask db upgrade
heroku run flask seed-db
```

## 💰 Revenue Model

| Stream | Pricing | Projected (Yr 1) |
|--------|---------|------------------|
| Premium Subscriptions | $29/mo or $249/yr | $360,000 |
| Course Sales | $99-$299 each | $75,000 |
| Event Tickets | $99-$499 each | $50,000 |
| Deal Placement Fees | 1-2% of raise | $40,000 |
| Advertising | $500-$2000/mo | $24,000 |
| **Total** | | **$549,000** |

## 🔒 Security Considerations

- All physicians verified by medical license
- Anonymous posting option for sensitive topics
- Stripe handles all payment data (PCI compliant)
- Password hashing with Werkzeug
- CSRF protection on all forms
- Rate limiting on API endpoints
- Investment disclaimers throughout

## 📞 Support

- Email: support@medinvest.com
- Documentation: docs.medinvest.com

## 📄 License

Proprietary - All Rights Reserved

---

Built with ❤️ for physicians
