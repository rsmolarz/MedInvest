"""
MedInvest - Complete Flask Application
Physician Investment Social Platform
"""
import os
from flask import Flask, render_template, redirect, url_for, request, flash, jsonify, Blueprint
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_migrate import Migrate
from datetime import datetime

# Initialize extensions
db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()


def create_app(config_name='development'):
    """Application factory"""
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///medinvest.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Stripe configuration
    app.config['STRIPE_SECRET_KEY'] = os.environ.get('STRIPE_SECRET_KEY')
    app.config['STRIPE_PUBLISHABLE_KEY'] = os.environ.get('STRIPE_PUBLISHABLE_KEY')
    app.config['STRIPE_WEBHOOK_SECRET'] = os.environ.get('STRIPE_WEBHOOK_SECRET')
    
    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    
    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'info'
    
    with app.app_context():
        # Import models after db initialization
        from models_complete import User
        
        @login_manager.user_loader
        def load_user(user_id):
            return User.query.get(int(user_id))
        
        # Register all blueprints
        from routes_complete import (
            ama_bp, deals_bp, subscription_bp, mentorship_bp,
            courses_bp, events_bp, referral_bp, portfolio_bp,
            ai_bp, admin_bp
        )
        
        app.register_blueprint(ama_bp)
        app.register_blueprint(deals_bp)
        app.register_blueprint(subscription_bp)
        app.register_blueprint(mentorship_bp)
        app.register_blueprint(courses_bp)
        app.register_blueprint(events_bp)
        app.register_blueprint(referral_bp)
        app.register_blueprint(portfolio_bp)
        app.register_blueprint(ai_bp)
        app.register_blueprint(admin_bp)
        
        # ====================================================================
        # MAIN ROUTES BLUEPRINT
        # ====================================================================
        
        main_bp = Blueprint('main', __name__)
        
        @main_bp.route('/')
        def index():
            if current_user.is_authenticated:
                return redirect(url_for('main.feed'))
            return render_template('index.html')
        
        @main_bp.route('/feed')
        @login_required
        def feed():
            return render_template('feed.html')
        
        @main_bp.route('/profile')
        @login_required
        def profile():
            return render_template('profile.html', user=current_user)
        
        @main_bp.route('/dashboard')
        @login_required
        def dashboard():
            return render_template('dashboard.html')
        
        app.register_blueprint(main_bp)
        
        # ====================================================================
        # AUTHENTICATION BLUEPRINT
        # ====================================================================
        
        auth_bp = Blueprint('auth', __name__, url_prefix='/auth')
        
        @auth_bp.route('/login', methods=['GET', 'POST'])
        def login():
            if current_user.is_authenticated:
                return redirect(url_for('main.feed'))
            
            if request.method == 'POST':
                email = request.form.get('email')
                password = request.form.get('password')
                
                user = User.query.filter_by(email=email).first()
                
                if user and user.check_password(password):
                    login_user(user)
                    user.last_login = datetime.utcnow()
                    db.session.commit()
                    
                    next_page = request.args.get('next')
                    flash('Welcome back!', 'success')
                    return redirect(next_page or url_for('main.feed'))
                
                flash('Invalid email or password', 'error')
            
            return render_template('auth/login.html')
        
        @auth_bp.route('/register', methods=['GET', 'POST'])
        def register():
            if current_user.is_authenticated:
                return redirect(url_for('main.feed'))
            
            if request.method == 'POST':
                email = request.form.get('email')
                password = request.form.get('password')
                first_name = request.form.get('first_name')
                last_name = request.form.get('last_name')
                medical_license = request.form.get('medical_license')
                specialty = request.form.get('specialty')
                
                if User.query.filter_by(email=email).first():
                    flash('Email already registered', 'error')
                    return render_template('auth/register.html')
                
                if User.query.filter_by(medical_license=medical_license).first():
                    flash('Medical license already registered', 'error')
                    return render_template('auth/register.html')
                
                user = User(
                    email=email,
                    first_name=first_name,
                    last_name=last_name,
                    medical_license=medical_license,
                    specialty=specialty
                )
                user.set_password(password)
                user.generate_referral_code()
                
                ref_code = request.form.get('referral_code') or request.args.get('ref')
                if ref_code:
                    referrer = User.query.filter_by(referral_code=ref_code.upper()).first()
                    if referrer:
                        user.referred_by_id = referrer.id
                        user.points = 50
                        referrer.points += 100
                
                db.session.add(user)
                db.session.commit()
                
                login_user(user)
                flash('Welcome to MedInvest!', 'success')
                return redirect(url_for('main.feed'))
            
            return render_template('auth/register.html')
        
        @auth_bp.route('/logout')
        @login_required
        def logout():
            logout_user()
            flash('You have been logged out', 'info')
            return redirect(url_for('main.index'))
        
        app.register_blueprint(auth_bp)
        
        # ====================================================================
        # ROOMS BLUEPRINT
        # ====================================================================
        
        rooms_bp = Blueprint('rooms', __name__, url_prefix='/rooms')
        
        @rooms_bp.route('/')
        @login_required
        def list_rooms():
            rooms = [
                {'id': 1, 'name': 'Index Fund Investors', 'category': 'Strategy', 'member_count': 1234},
                {'id': 2, 'name': 'Real Estate Physicians', 'category': 'Strategy', 'member_count': 892},
                {'id': 3, 'name': 'FIRE Movement', 'category': 'Strategy', 'member_count': 756},
                {'id': 4, 'name': 'Cardiology Investors', 'category': 'Specialty', 'member_count': 543},
                {'id': 5, 'name': 'Surgery Investors', 'category': 'Specialty', 'member_count': 432},
                {'id': 6, 'name': 'Residents & Fellows', 'category': 'Career Stage', 'member_count': 1567},
                {'id': 7, 'name': 'Attending Physicians', 'category': 'Career Stage', 'member_count': 2341},
            ]
            return render_template('rooms/list.html', rooms=rooms)
        
        @rooms_bp.route('/<int:room_id>')
        @login_required
        def view_room(room_id):
            return render_template('rooms/detail.html', room_id=room_id)
        
        app.register_blueprint(rooms_bp)
        
        # ====================================================================
        # ERROR HANDLERS
        # ====================================================================
        
        @app.errorhandler(404)
        def not_found_error(error):
            return render_template('errors/404.html'), 404
        
        @app.errorhandler(500)
        def internal_error(error):
            db.session.rollback()
            return render_template('errors/500.html'), 500
        
        @app.errorhandler(403)
        def forbidden_error(error):
            return render_template('errors/403.html'), 403
        
        # ====================================================================
        # CONTEXT PROCESSORS
        # ====================================================================
        
        @app.context_processor
        def utility_processor():
            return {
                'now': datetime.utcnow(),
                'app_name': 'MedInvest'
            }
        
        # ====================================================================
        # CLI COMMANDS
        # ====================================================================
        
        @app.cli.command('init-db')
        def init_db_command():
            db.create_all()
            print('Database initialized.')
        
        @app.cli.command('seed-db')
        def seed_db_command():
            from seed_data import seed_database
            seed_database(db)
            print('Database seeded.')
    
    return app


# Create the application instance
app = create_app()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
