"""
Seed Data for MedInvest Platform
Run with: flask seed-db
"""
from datetime import datetime, timedelta
import random


def seed_database(db):
    """Seed the database with sample data"""
    from models_complete import (
        User, SubscriptionTier,
        ExpertAMA, AMAStatus,
        InvestmentDeal, DealStatus,
        Course, CourseModule,
        Event, EventSession
    )
    
    print("Seeding database...")
    
    # Create sample users
    users = []
    specialties = [
        'cardiology', 'orthopedics', 'dermatology', 'radiology', 
        'anesthesiology', 'emergency_medicine', 'internal_medicine',
        'surgery', 'pediatrics', 'psychiatry'
    ]
    
    # Admin user
    admin = User(
        email='admin@medinvest.com',
        first_name='Admin',
        last_name='User',
        medical_license='ADMIN001',
        specialty='internal_medicine',
        is_admin=True,
        is_verified=True,
        subscription_tier=SubscriptionTier.PREMIUM,
        points=10000,
        level=10
    )
    admin.set_password('admin123')
    admin.generate_referral_code()
    db.session.add(admin)
    users.append(admin)
    
    # Sample physicians
    first_names = ['James', 'Sarah', 'Michael', 'Emily', 'David', 'Jennifer', 'Robert', 'Lisa', 'William', 'Amanda']
    last_names = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Martinez', 'Wilson']
    
    for i in range(20):
        user = User(
            email=f'doctor{i+1}@example.com',
            first_name=random.choice(first_names),
            last_name=random.choice(last_names),
            medical_license=f'MD{100000 + i}',
            specialty=random.choice(specialties),
            is_verified=random.random() > 0.3,
            subscription_tier=SubscriptionTier.PREMIUM if random.random() > 0.7 else SubscriptionTier.FREE,
            points=random.randint(100, 5000),
            level=random.randint(1, 8),
            years_of_experience=random.randint(1, 25),
            bio=f"Physician with {random.randint(5, 20)} years of experience. Passionate about investing."
        )
        user.set_password('password123')
        user.generate_referral_code()
        db.session.add(user)
        users.append(user)
    
    db.session.commit()
    print(f"Created {len(users)} users")
    
    # Create AMAs
    ama_topics = [
        ("Tax Strategies for High-Income Physicians", "John Smith, CPA", "Managing Partner at PhysicianTax LLC"),
        ("Real Estate Investing 101", "Dr. Emily Chen", "Orthopedic Surgeon & Real Estate Investor"),
        ("Student Loan Strategies: PSLF vs Refinance", "Maria Garcia", "Student Loan Expert"),
        ("Building a Passive Income Portfolio", "Dr. Robert Williams", "Retired Cardiologist"),
        ("Protecting Your Assets: Estate Planning", "David Miller, JD", "Healthcare Attorney"),
    ]
    
    for i, (title, expert, expert_title) in enumerate(ama_topics):
        ama = ExpertAMA(
            title=title,
            expert_name=expert,
            expert_title=expert_title,
            expert_bio=f"{expert} is a leading expert in physician finance with over 15 years of experience.",
            description=f"Join us for an in-depth discussion on {title.lower()}. Submit your questions in advance!",
            scheduled_for=datetime.utcnow() + timedelta(days=7 + i*7),
            duration_minutes=60,
            status=AMAStatus.SCHEDULED,
            is_premium_only=i > 2,
            participant_count=random.randint(50, 200),
            question_count=random.randint(10, 50)
        )
        db.session.add(ama)
    
    # Past AMA with recording
    past_ama = ExpertAMA(
        title="Introduction to Index Fund Investing",
        expert_name="Dr. Lisa Davis",
        expert_title="Internist & FIRE Blogger",
        description="A comprehensive overview of index fund investing for physicians.",
        scheduled_for=datetime.utcnow() - timedelta(days=14),
        duration_minutes=75,
        status=AMAStatus.ENDED,
        recording_url="https://youtube.com/example",
        participant_count=342,
        question_count=89
    )
    db.session.add(past_ama)
    db.session.commit()
    print("Created AMAs")
    
    # Create Investment Deals
    deals_data = [
        {
            'title': 'Phoenix Medical Office Building',
            'deal_type': 'real_estate',
            'minimum_investment': 50000,
            'target_raise': 2500000,
            'current_raised': 1750000,
            'projected_return': '14-18% IRR',
            'investment_term': '5 years',
            'location': 'Phoenix, AZ',
            'sponsor_name': 'MedReal Capital',
            'description': 'Class A medical office building in high-growth Phoenix suburb. NNN lease with hospital anchor tenant.'
        },
        {
            'title': 'Healthcare Innovation Fund II',
            'deal_type': 'fund',
            'minimum_investment': 25000,
            'target_raise': 10000000,
            'current_raised': 6200000,
            'projected_return': '20%+ Target',
            'investment_term': '7-10 years',
            'sponsor_name': 'HealthTech Ventures',
            'description': 'Venture fund focused on early-stage healthcare technology companies. Physician-led deals.'
        },
        {
            'title': 'Dermatology Practice Acquisition',
            'deal_type': 'practice',
            'minimum_investment': 100000,
            'target_raise': 1500000,
            'current_raised': 900000,
            'projected_return': '25%+ Cash-on-Cash',
            'investment_term': '3-5 years',
            'location': 'Dallas, TX',
            'sponsor_name': 'Physician Partners Group',
            'description': 'Acquisition of established 3-physician dermatology practice with strong cosmetic revenue.'
        },
        {
            'title': 'Austin Multi-Family Syndicate',
            'deal_type': 'syndicate',
            'minimum_investment': 75000,
            'target_raise': 5000000,
            'current_raised': 3100000,
            'projected_return': '15-20% IRR',
            'investment_term': '5-7 years',
            'location': 'Austin, TX',
            'sponsor_name': 'Lone Star Capital',
            'description': '200-unit Class B apartment complex in rapidly growing Austin suburb. Value-add opportunity.'
        },
    ]
    
    for deal_data in deals_data:
        deal = InvestmentDeal(
            title=deal_data['title'],
            description=deal_data['description'],
            deal_type=deal_data['deal_type'],
            minimum_investment=deal_data['minimum_investment'],
            target_raise=deal_data['target_raise'],
            current_raised=deal_data['current_raised'],
            projected_return=deal_data['projected_return'],
            investment_term=deal_data['investment_term'],
            location=deal_data.get('location'),
            sponsor_name=deal_data['sponsor_name'],
            sponsor_bio=f"{deal_data['sponsor_name']} has completed over 20 successful investments.",
            status=DealStatus.ACTIVE,
            is_featured=random.random() > 0.7,
            accredited_only=True,
            physician_only=random.random() > 0.5,
            view_count=random.randint(100, 500),
            interest_count=random.randint(10, 50)
        )
        db.session.add(deal)
    
    db.session.commit()
    print("Created investment deals")
    
    # Create Courses
    courses_data = [
        {
            'title': 'Personal Finance for Physicians 101',
            'description': 'Master the fundamentals of personal finance tailored specifically for medical professionals.',
            'price': 149,
            'instructor_name': 'Dr. James Wilson',
            'total_modules': 8,
            'total_duration_minutes': 360,
            'modules': ['Introduction', 'Budgeting', 'Emergency Fund', 'Insurance', 'Retirement Accounts', 'Investing Basics', 'Tax Strategies', 'Next Steps']
        },
        {
            'title': 'Real Estate Investing for Busy Doctors',
            'description': 'Learn how to build passive income through real estate while maintaining your medical career.',
            'price': 299,
            'instructor_name': 'Dr. Emily Chen',
            'total_modules': 12,
            'total_duration_minutes': 540,
            'modules': ['Why Real Estate', 'Market Analysis', 'Financing', 'Rental Properties', 'Syndications', 'REITs', 'Tax Benefits', '1031 Exchanges', 'Due Diligence', 'Property Management', 'Scaling', 'Case Studies']
        },
        {
            'title': 'Student Loan Mastery',
            'description': 'Navigate your student loans strategically - PSLF, refinancing, and payoff strategies.',
            'price': 99,
            'instructor_name': 'Maria Garcia',
            'total_modules': 6,
            'total_duration_minutes': 180,
            'modules': ['Loan Overview', 'PSLF Deep Dive', 'IDR Plans', 'Refinancing', 'Payoff Strategies', 'Action Plan']
        },
    ]
    
    for course_data in courses_data:
        course = Course(
            title=course_data['title'],
            description=course_data['description'],
            price=course_data['price'],
            instructor_name=course_data['instructor_name'],
            total_modules=course_data['total_modules'],
            total_duration_minutes=course_data['total_duration_minutes'],
            is_published=True,
            is_featured=random.random() > 0.5,
            enrolled_count=random.randint(50, 300),
            difficulty_level='beginner' if '101' in course_data['title'] else 'intermediate'
        )
        db.session.add(course)
        db.session.flush()
        
        # Add modules
        for i, module_title in enumerate(course_data['modules']):
            module = CourseModule(
                course_id=course.id,
                title=module_title,
                description=f"Learn about {module_title.lower()} in this comprehensive module.",
                order_index=i,
                duration_minutes=course_data['total_duration_minutes'] // course_data['total_modules']
            )
            db.session.add(module)
    
    db.session.commit()
    print("Created courses")
    
    # Create Events
    events_data = [
        {
            'title': 'Physician Wealth Summit 2024',
            'description': 'The premier conference for physician investors. Network, learn, and grow your wealth.',
            'is_virtual': False,
            'venue_name': 'Marriott Marquis',
            'venue_address': 'San Diego, CA',
            'regular_price': 499,
            'early_bird_price': 399,
            'vip_price': 899,
            'days_until': 60
        },
        {
            'title': 'Virtual Tax Planning Workshop',
            'description': 'Year-end tax strategies for high-income physicians. Live Q&A with CPAs.',
            'is_virtual': True,
            'regular_price': 99,
            'early_bird_price': 79,
            'days_until': 14
        },
    ]
    
    for event_data in events_data:
        event = Event(
            title=event_data['title'],
            description=event_data['description'],
            is_virtual=event_data['is_virtual'],
            venue_name=event_data.get('venue_name'),
            venue_address=event_data.get('venue_address'),
            start_date=datetime.utcnow() + timedelta(days=event_data['days_until']),
            end_date=datetime.utcnow() + timedelta(days=event_data['days_until'] + 1),
            timezone='America/Los_Angeles',
            regular_price=event_data['regular_price'],
            early_bird_price=event_data['early_bird_price'],
            early_bird_ends=datetime.utcnow() + timedelta(days=event_data['days_until'] - 14),
            vip_price=event_data.get('vip_price'),
            max_attendees=500 if not event_data['is_virtual'] else None,
            current_attendees=random.randint(50, 200),
            is_published=True,
            is_featured=True
        )
        db.session.add(event)
    
    db.session.commit()
    print("Created events")
    
    print("Database seeding complete!")
