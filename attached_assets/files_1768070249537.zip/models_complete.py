"""
Complete MedInvest Platform Models
Includes: AMAs, Deal Flow, Premium Subscriptions, Mentorship, Events, Referrals
"""
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from sqlalchemy import Index
import enum


# ============================================================================
# ENUMS
# ============================================================================

class SubscriptionTier(enum.Enum):
    FREE = "free"
    PREMIUM = "premium"
    ENTERPRISE = "enterprise"


class DealStatus(enum.Enum):
    DRAFT = "draft"
    REVIEW = "review"
    ACTIVE = "active"
    CLOSED = "closed"
    REJECTED = "rejected"


class AMAStatus(enum.Enum):
    SCHEDULED = "scheduled"
    LIVE = "live"
    ENDED = "ended"
    CANCELLED = "cancelled"


class MentorshipStatus(enum.Enum):
    PENDING = "pending"
    ACTIVE = "active"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


# ============================================================================
# USER & CORE MODELS (Enhanced)
# ============================================================================

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    medical_license = db.Column(db.String(50), unique=True, nullable=False)
    specialty = db.Column(db.String(100), nullable=False)
    hospital_affiliation = db.Column(db.String(200))
    bio = db.Column(db.Text)
    profile_image_url = db.Column(db.String(500))
    location = db.Column(db.String(100))
    years_of_experience = db.Column(db.Integer)
    investment_interests = db.Column(db.Text)
    is_verified = db.Column(db.Boolean, default=False)
    account_active = db.Column(db.Boolean, default=True)
    
    # Premium features
    subscription_tier = db.Column(db.Enum(SubscriptionTier), default=SubscriptionTier.FREE)
    stripe_customer_id = db.Column(db.String(100))
    subscription_ends_at = db.Column(db.DateTime)
    
    # Gamification
    points = db.Column(db.Integer, default=0)
    level = db.Column(db.Integer, default=1)
    
    # Referrals
    referral_code = db.Column(db.String(20), unique=True, index=True)
    referred_by_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    # Stats
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)
    login_streak = db.Column(db.Integer, default=0)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    posts = db.relationship('Post', back_populates='author', lazy='dynamic')
    achievements = db.relationship('UserAchievement', back_populates='user', lazy='dynamic')
    room_memberships = db.relationship('RoomMembership', back_populates='user', lazy='dynamic')
    subscriptions = db.relationship('Subscription', back_populates='user', lazy='dynamic')
    referrals_made = db.relationship('User', backref=db.backref('referred_by', remote_side=[id]))
    
    # Mentorship
    mentorships_as_mentor = db.relationship('Mentorship', 
                                           foreign_keys='Mentorship.mentor_id',
                                           back_populates='mentor', lazy='dynamic')
    mentorships_as_mentee = db.relationship('Mentorship',
                                           foreign_keys='Mentorship.mentee_id',
                                           back_populates='mentee', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    @property
    def is_premium(self):
        if self.subscription_tier == SubscriptionTier.FREE:
            return False
        if self.subscription_ends_at and self.subscription_ends_at < datetime.utcnow():
            return False
        return True
    
    def generate_referral_code(self):
        """Generate unique referral code"""
        import random
        import string
        while True:
            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            if not User.query.filter_by(referral_code=code).first():
                self.referral_code = code
                return code


# ============================================================================
# SUBSCRIPTION & PAYMENTS
# ============================================================================

class Subscription(db.Model):
    """Track subscription history and payments"""
    __tablename__ = 'subscriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    tier = db.Column(db.Enum(SubscriptionTier), nullable=False)
    stripe_subscription_id = db.Column(db.String(100), unique=True)
    stripe_price_id = db.Column(db.String(100))
    
    amount = db.Column(db.Float, nullable=False)  # in USD
    interval = db.Column(db.String(20))  # 'month' or 'year'
    
    status = db.Column(db.String(20))  # active, cancelled, past_due, etc.
    current_period_start = db.Column(db.DateTime)
    current_period_end = db.Column(db.DateTime)
    cancel_at_period_end = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = db.relationship('User', back_populates='subscriptions')


class Payment(db.Model):
    """Track individual payments"""
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    stripe_payment_intent_id = db.Column(db.String(100), unique=True)
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='USD')
    
    status = db.Column(db.String(20))  # succeeded, pending, failed
    payment_type = db.Column(db.String(50))  # subscription, course, event, etc.
    
    metadata = db.Column(db.JSON)  # Additional info
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='payments')


# ============================================================================
# EXPERT AMAs
# ============================================================================

class ExpertAMA(db.Model):
    """Scheduled Q&A sessions with experts"""
    __tablename__ = 'expert_amas'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Expert info
    expert_name = db.Column(db.String(200), nullable=False)
    expert_title = db.Column(db.String(200))  # "CFP, CPA", "MD, MBA", etc.
    expert_bio = db.Column(db.Text)
    expert_image_url = db.Column(db.String(500))
    
    # AMA details
    title = db.Column(db.String(300), nullable=False)
    description = db.Column(db.Text, nullable=False)
    topic_tags = db.Column(db.String(500))  # Comma-separated
    
    # Scheduling
    scheduled_for = db.Column(db.DateTime, nullable=False, index=True)
    duration_minutes = db.Column(db.Integer, default=60)
    status = db.Column(db.Enum(AMAStatus), default=AMAStatus.SCHEDULED)
    
    # Access control
    is_premium_only = db.Column(db.Boolean, default=False)
    max_participants = db.Column(db.Integer)
    
    # Sponsorship
    sponsor_name = db.Column(db.String(200))
    sponsor_logo_url = db.Column(db.String(500))
    sponsor_url = db.Column(db.String(500))
    
    # Recording
    recording_url = db.Column(db.String(500))
    recording_price = db.Column(db.Float)  # Price for non-attendees
    
    # Stats
    participant_count = db.Column(db.Integer, default=0)
    question_count = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    questions = db.relationship('AMAQuestion', back_populates='ama', lazy='dynamic')
    registrations = db.relationship('AMARegistration', back_populates='ama', lazy='dynamic')


class AMAQuestion(db.Model):
    """Questions asked during AMA"""
    __tablename__ = 'ama_questions'
    
    id = db.Column(db.Integer, primary_key=True)
    ama_id = db.Column(db.Integer, db.ForeignKey('expert_amas.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    question = db.Column(db.Text, nullable=False)
    is_anonymous = db.Column(db.Boolean, default=False)
    
    # Voting
    upvotes = db.Column(db.Integer, default=0)
    
    # Answer
    answer = db.Column(db.Text)
    answered_at = db.Column(db.DateTime)
    is_answered = db.Column(db.Boolean, default=False)
    
    # Timing
    asked_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    ama = db.relationship('ExpertAMA', back_populates='questions')
    user = db.relationship('User', backref='ama_questions')


class AMARegistration(db.Model):
    """Track who registered for AMAs"""
    __tablename__ = 'ama_registrations'
    
    id = db.Column(db.Integer, primary_key=True)
    ama_id = db.Column(db.Integer, db.ForeignKey('expert_amas.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    attended = db.Column(db.Boolean, default=False)
    registered_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    ama = db.relationship('ExpertAMA', back_populates='registrations')
    user = db.relationship('User', backref='ama_registrations')
    
    __table_args__ = (db.UniqueConstraint('ama_id', 'user_id', name='unique_ama_registration'),)


# ============================================================================
# DEAL FLOW / INVESTMENT MARKETPLACE
# ============================================================================

class InvestmentDeal(db.Model):
    """Investment opportunities for physicians"""
    __tablename__ = 'investment_deals'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Deal basics
    title = db.Column(db.String(300), nullable=False)
    description = db.Column(db.Text, nullable=False)
    deal_type = db.Column(db.String(50), nullable=False)  # real_estate, fund, practice, syndicate
    
    # Financial details
    minimum_investment = db.Column(db.Float, nullable=False)
    target_raise = db.Column(db.Float)
    current_raised = db.Column(db.Float, default=0)
    
    # Returns
    projected_return = db.Column(db.String(50))  # "8-12% annually"
    investment_term = db.Column(db.String(50))  # "5 years"
    
    # Requirements
    accredited_only = db.Column(db.Boolean, default=True)
    physician_only = db.Column(db.Boolean, default=False)
    
    # Sponsor/Manager
    sponsor_name = db.Column(db.String(200), nullable=False)
    sponsor_bio = db.Column(db.Text)
    sponsor_track_record = db.Column(db.Text)
    sponsor_contact = db.Column(db.String(200))
    
    # Location (for real estate)
    location = db.Column(db.String(200))
    
    # Documents
    offering_document_url = db.Column(db.String(500))
    pitch_deck_url = db.Column(db.String(500))
    
    # Status
    status = db.Column(db.Enum(DealStatus), default=DealStatus.DRAFT)
    deadline = db.Column(db.DateTime)
    
    # Features
    is_featured = db.Column(db.Boolean, default=False)
    featured_until = db.Column(db.DateTime)
    
    # Stats
    view_count = db.Column(db.Integer, default=0)
    interest_count = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    interests = db.relationship('DealInterest', back_populates='deal', lazy='dynamic')


class DealInterest(db.Model):
    """Track user interest in deals"""
    __tablename__ = 'deal_interests'
    
    id = db.Column(db.Integer, primary_key=True)
    deal_id = db.Column(db.Integer, db.ForeignKey('investment_deals.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    investment_amount = db.Column(db.Float)
    message = db.Column(db.Text)
    
    status = db.Column(db.String(20), default='interested')  # interested, contacted, invested
    contacted_at = db.Column(db.DateTime)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    deal = db.relationship('InvestmentDeal', back_populates='interests')
    user = db.relationship('User', backref='deal_interests')
    
    __table_args__ = (db.UniqueConstraint('deal_id', 'user_id', name='unique_deal_interest'),)


# ============================================================================
# MENTORSHIP
# ============================================================================

class Mentorship(db.Model):
    """Mentor-mentee relationships"""
    __tablename__ = 'mentorships'
    
    id = db.Column(db.Integer, primary_key=True)
    mentor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    mentee_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Program details
    focus_areas = db.Column(db.String(500))  # "Student loans, Real estate, Index funds"
    duration_months = db.Column(db.Integer, default=3)
    
    status = db.Column(db.Enum(MentorshipStatus), default=MentorshipStatus.PENDING)
    
    # Scheduling
    start_date = db.Column(db.DateTime)
    end_date = db.Column(db.DateTime)
    
    # Meetings
    total_meetings = db.Column(db.Integer, default=0)
    last_meeting = db.Column(db.DateTime)
    
    # Feedback
    mentor_rating = db.Column(db.Integer)  # 1-5
    mentee_rating = db.Column(db.Integer)  # 1-5
    mentor_feedback = db.Column(db.Text)
    mentee_feedback = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    mentor = db.relationship('User', foreign_keys=[mentor_id], back_populates='mentorships_as_mentor')
    mentee = db.relationship('User', foreign_keys=[mentee_id], back_populates='mentorships_as_mentee')
    sessions = db.relationship('MentorshipSession', back_populates='mentorship', lazy='dynamic')


class MentorshipSession(db.Model):
    """Individual mentorship meetings"""
    __tablename__ = 'mentorship_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    mentorship_id = db.Column(db.Integer, db.ForeignKey('mentorships.id'), nullable=False)
    
    scheduled_for = db.Column(db.DateTime, nullable=False)
    duration_minutes = db.Column(db.Integer, default=30)
    
    topics_discussed = db.Column(db.Text)
    action_items = db.Column(db.Text)
    notes = db.Column(db.Text)
    
    completed = db.Column(db.Boolean, default=False)
    completed_at = db.Column(db.DateTime)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    mentorship = db.relationship('Mentorship', back_populates='sessions')


# ============================================================================
# COURSES & EDUCATIONAL CONTENT
# ============================================================================

class Course(db.Model):
    """Premium courses"""
    __tablename__ = 'courses'
    
    id = db.Column(db.Integer, primary_key=True)
    
    title = db.Column(db.String(300), nullable=False)
    description = db.Column(db.Text, nullable=False)
    instructor_name = db.Column(db.String(200))
    
    # Pricing
    price = db.Column(db.Float, nullable=False)
    original_price = db.Column(db.Float)  # For showing discounts
    
    # Content
    total_modules = db.Column(db.Integer, default=0)
    total_duration_minutes = db.Column(db.Integer, default=0)
    difficulty_level = db.Column(db.String(20))  # Beginner, Intermediate, Advanced
    
    # Media
    thumbnail_url = db.Column(db.String(500))
    preview_video_url = db.Column(db.String(500))
    
    # Status
    is_published = db.Column(db.Boolean, default=False)
    is_featured = db.Column(db.Boolean, default=False)
    
    # Stats
    enrolled_count = db.Column(db.Integer, default=0)
    completion_rate = db.Column(db.Float, default=0)
    avg_rating = db.Column(db.Float, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    modules = db.relationship('CourseModule', back_populates='course', lazy='dynamic')
    enrollments = db.relationship('CourseEnrollment', back_populates='course', lazy='dynamic')


class CourseModule(db.Model):
    """Course content modules"""
    __tablename__ = 'course_modules'
    
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    
    title = db.Column(db.String(300), nullable=False)
    description = db.Column(db.Text)
    content = db.Column(db.Text)  # HTML content
    
    video_url = db.Column(db.String(500))
    duration_minutes = db.Column(db.Integer)
    
    order_index = db.Column(db.Integer, default=0)
    
    # Resources
    downloadable_resources = db.Column(db.JSON)  # List of file URLs
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    course = db.relationship('Course', back_populates='modules')


class CourseEnrollment(db.Model):
    """Track course purchases and progress"""
    __tablename__ = 'course_enrollments'
    
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Purchase
    purchase_price = db.Column(db.Float, nullable=False)
    payment_id = db.Column(db.Integer, db.ForeignKey('payments.id'))
    
    # Progress
    progress_percent = db.Column(db.Float, default=0)
    completed_modules = db.Column(db.JSON)  # List of completed module IDs
    completed = db.Column(db.Boolean, default=False)
    completed_at = db.Column(db.DateTime)
    
    # Rating
    rating = db.Column(db.Integer)  # 1-5
    review = db.Column(db.Text)
    
    enrolled_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    course = db.relationship('Course', back_populates='enrollments')
    user = db.relationship('User', backref='course_enrollments')
    
    __table_args__ = (db.UniqueConstraint('course_id', 'user_id', name='unique_course_enrollment'),)


# ============================================================================
# EVENTS & CONFERENCES
# ============================================================================

class Event(db.Model):
    """Virtual conferences and events"""
    __tablename__ = 'events'
    
    id = db.Column(db.Integer, primary_key=True)
    
    title = db.Column(db.String(300), nullable=False)
    description = db.Column(db.Text, nullable=False)
    
    # Type
    event_type = db.Column(db.String(50))  # conference, workshop, networking
    
    # Scheduling
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime, nullable=False)
    timezone = db.Column(db.String(50), default='America/New_York')
    
    # Virtual/Physical
    is_virtual = db.Column(db.Boolean, default=True)
    venue_name = db.Column(db.String(200))
    venue_address = db.Column(db.Text)
    
    # Access
    meeting_url = db.Column(db.String(500))
    meeting_password = db.Column(db.String(100))
    
    # Pricing
    early_bird_price = db.Column(db.Float)
    early_bird_ends = db.Column(db.DateTime)
    regular_price = db.Column(db.Float, nullable=False)
    vip_price = db.Column(db.Float)
    
    # Capacity
    max_attendees = db.Column(db.Integer)
    current_attendees = db.Column(db.Integer, default=0)
    
    # Status
    is_published = db.Column(db.Boolean, default=False)
    is_featured = db.Column(db.Boolean, default=False)
    
    # Media
    banner_url = db.Column(db.String(500))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    registrations = db.relationship('EventRegistration', back_populates='event', lazy='dynamic')
    sessions = db.relationship('EventSession', back_populates='event', lazy='dynamic')


class EventSession(db.Model):
    """Individual sessions within an event"""
    __tablename__ = 'event_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    
    title = db.Column(db.String(300), nullable=False)
    description = db.Column(db.Text)
    speaker_name = db.Column(db.String(200))
    speaker_bio = db.Column(db.Text)
    
    start_time = db.Column(db.DateTime, nullable=False)
    duration_minutes = db.Column(db.Integer, default=60)
    
    recording_url = db.Column(db.String(500))
    
    event = db.relationship('Event', back_populates='sessions')


class EventRegistration(db.Model):
    """Event ticket purchases"""
    __tablename__ = 'event_registrations'
    
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    ticket_type = db.Column(db.String(20))  # regular, vip
    purchase_price = db.Column(db.Float, nullable=False)
    payment_id = db.Column(db.Integer, db.ForeignKey('payments.id'))
    
    attended = db.Column(db.Boolean, default=False)
    check_in_time = db.Column(db.DateTime)
    
    registered_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    event = db.relationship('Event', back_populates='registrations')
    user = db.relationship('User', backref='event_registrations')
    
    __table_args__ = (db.UniqueConstraint('event_id', 'user_id', name='unique_event_registration'),)


# ============================================================================
# REFERRAL PROGRAM
# ============================================================================

class Referral(db.Model):
    """Track referrals and rewards"""
    __tablename__ = 'referrals'
    
    id = db.Column(db.Integer, primary_key=True)
    referrer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    referred_user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    
    referral_code_used = db.Column(db.String(20))
    
    # Status
    status = db.Column(db.String(20), default='pending')  # pending, completed, rewarded
    
    # Rewards
    reward_type = db.Column(db.String(50))  # points, premium_month, cash
    reward_value = db.Column(db.Float)
    rewarded_at = db.Column(db.DateTime)
    
    # Conversion tracking
    referred_user_activated = db.Column(db.Boolean, default=False)  # Made first post
    referred_user_premium = db.Column(db.Boolean, default=False)  # Became premium
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    referrer = db.relationship('User', foreign_keys=[referrer_id], backref='referrals_sent')
    referred_user = db.relationship('User', foreign_keys=[referred_user_id], backref='referral_received')


# ============================================================================
# ANALYTICS & PORTFOLIO TRACKING
# ============================================================================

class PortfolioConnection(db.Model):
    """Plaid/broker account connections"""
    __tablename__ = 'portfolio_connections'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Plaid info
    plaid_access_token = db.Column(db.String(500))  # Encrypted
    plaid_item_id = db.Column(db.String(200))
    
    institution_name = db.Column(db.String(200))
    institution_id = db.Column(db.String(100))
    
    # Connection status
    is_active = db.Column(db.Boolean, default=True)
    last_synced = db.Column(db.DateTime)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='portfolio_connections')


class PortfolioSnapshot(db.Model):
    """Daily portfolio snapshots for tracking"""
    __tablename__ = 'portfolio_snapshots'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    snapshot_date = db.Column(db.Date, nullable=False, index=True)
    
    # Totals
    total_value = db.Column(db.Float, nullable=False)
    cash = db.Column(db.Float, default=0)
    stocks = db.Column(db.Float, default=0)
    bonds = db.Column(db.Float, default=0)
    real_estate = db.Column(db.Float, default=0)
    crypto = db.Column(db.Float, default=0)
    other = db.Column(db.Float, default=0)
    
    # Performance
    daily_change = db.Column(db.Float)
    daily_change_percent = db.Column(db.Float)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='portfolio_snapshots')
    
    __table_args__ = (
        db.UniqueConstraint('user_id', 'snapshot_date', name='unique_daily_snapshot'),
        Index('idx_user_date', 'user_id', 'snapshot_date'),
    )


# ============================================================================
# EMAIL CAMPAIGNS
# ============================================================================

class EmailCampaign(db.Model):
    """Email marketing campaigns"""
    __tablename__ = 'email_campaigns'
    
    id = db.Column(db.Integer, primary_key=True)
    
    name = db.Column(db.String(200), nullable=False)
    subject = db.Column(db.String(300), nullable=False)
    
    # Content
    html_content = db.Column(db.Text, nullable=False)
    text_content = db.Column(db.Text)
    
    # Targeting
    segment = db.Column(db.String(100))  # 'all', 'free', 'premium', 'specialty_cardiology', etc.
    
    # Scheduling
    send_at = db.Column(db.DateTime)
    sent = db.Column(db.Boolean, default=False)
    sent_at = db.Column(db.DateTime)
    
    # Stats
    total_recipients = db.Column(db.Integer, default=0)
    opened = db.Column(db.Integer, default=0)
    clicked = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


# Add indexes for performance
Index('idx_user_email', User.email)
Index('idx_user_specialty', User.specialty)
Index('idx_ama_scheduled', ExpertAMA.scheduled_for)
Index('idx_deal_status', InvestmentDeal.status)
