import InvitePanel from '@/components/InvitePanel';

export default function InvitesPage() {
  return <InvitePanel />;
}
