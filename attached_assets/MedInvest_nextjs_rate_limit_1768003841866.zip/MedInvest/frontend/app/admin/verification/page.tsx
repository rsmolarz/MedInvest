import AdminVerificationTable from "@/components/AdminVerificationTable";

export default function AdminVerificationPage() {
  return (
    <main>
      <AdminVerificationTable />
    </main>
  );
}
