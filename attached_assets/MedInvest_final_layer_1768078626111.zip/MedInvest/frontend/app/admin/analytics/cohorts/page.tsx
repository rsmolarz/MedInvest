import AdminCohortAnalytics from "@/components/admin/AdminCohortAnalytics";

export default function AdminAnalyticsCohortsPage() {
  return (
    <main>
      <AdminCohortAnalytics />
    </main>
  );
}
