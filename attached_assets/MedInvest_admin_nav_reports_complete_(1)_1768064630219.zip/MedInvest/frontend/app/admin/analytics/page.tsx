import AdminAnalyticsOverview from "@/components/admin/AdminAnalyticsOverview";

export default function AdminAnalyticsPage() {
  return (
    <main>
      <AdminAnalyticsOverview />
    </main>
  );
}
