import DealWizard from '@/components/DealWizard';

export default function NewDealPage() {
  return <DealWizard />;
}
